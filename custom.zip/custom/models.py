# Create models required for custom database/implementation here
