import logging

from botbuilder.dialogs import Dialog
from django.http import HttpResponse

from aistudiobot.hooks import ChatbotHooks
from custom.helpers.custom_bot_helper import Custom_Bot_Helper
from aistudiobot.schedules import Schedule, ScheduleTrigger
from django.utils import timezone

# All logs will be available in logs/custom.log
logger = logging.getLogger(__name__)


class CustomChatbotHooks(ChatbotHooks):
    # Add all custom dialog objects to export_dialogs list. Only the dialogs in the list will be registered during execution.
    export_dialogs = []

    async def root_dialog_hook(conv_state, user_state, turn_context) -> Dialog:
        """This method will be invoked before matching triggers from our chatbot.
        Can be used to invoke custom dialogs by return a dialog object that is also available in global var export_dialogs

        Args:
            conv_state (botbuilder.core.ConversationState)
            user_state (botbuilder.core.UserState)
            turn_context (botbuilder.core.TurnContext)

        Returns:
            botbuilder.dialogs.Dialog : Dialog to be invoked, return None if not invoking dialogs.
        """
        logger.info("Root dialog hook called", Dialog)
        await Custom_Bot_Helper.get_mobilenumber(turn_context,conv_state)
        await Custom_Bot_Helper.check_access(turn_context,conv_state)
        # await Custom_Bot_Helper.fetch_employee_details(turn_context,conv_state)
        return None

    async def storecon_hook(turn_context):
        """This method will be invoked for every activity before user chat history is logged

        Args:
            turn_context (botbuilder.core.TurnContext)
        """
        logger.info("Storecon hook called")
        return None

    async def custom_view_hook(request) -> HttpResponse:
        """This method will be invoked when api/custom REST API is called from any source.

        Args:
            request : Request object sent while invoking the REST API

        Returns:
            HttpResponse : The http reponse for the REST API invocation, return HttpResponse 400 if not implemented
        """
        logger.info("Custom view hook called")
        return HttpResponse(status=400)

    async def webchat_join_event_hook(conv_state, user_state, turn_context):
        """This method will be invoked when user starts a new conversation

        Args:
            conv_state (botbuilder.core.ConversationState)
            user_state (botbuilder.core.UserState)
            turn_context (botbuilder.core.TurnContext)
        """
        logger.info("Webchat join hook called")
        return None

    async def aistudio_dialog_element_hook(conv_state, user_state, turn_context):
        """This method is invoked before executing any dialog element

        Args:
            conv_state (botbuilder.core.ConversationState)
            user_state (botbuilder.core.UserState)
            turn_context (botbuilder.core.TurnContext)
        """
        logger.info("AIStudio dialog hook called")
        return None

    async def api_messages_hook(request, activity):
        """This method is invoked for every api/messages REST API invocation

        Args:
            request : Request object sent while invoking the REST API
            activity : Activity object
        """
        logger.info("api messages hook called")
        return None

    async def api_reply_hook(request, body):
        """This method is invoked for every api/reply REST API invocation

        Args:
            request : Request object sent while invoking the REST API
            body : JSON string body with details of the workflow response
        """
        logger.info("api reply hook called")
        return None

    async def cancel_conv_hook(conv_state, user_state, turn_context):
        """This method is invoked when a conversation is cancelled

        Args:
            conv_state (botbuilder.core.ConversationState)
            user_state (botbuilder.core.UserState)
            turn_context (botbuilder.core.TurnContext)
        """
        logger.info("Cancel conversation hook called")
        return None

    async def voice_bot_start_conv_hook(request, file_data):
        """This method is invoked before sending data to start a voice call.

        Args:
            request : Request object sent while invoking the REST API
            file_data : CSV file (; separator) contents, i.e. phone numbers and required details

        Return:
            file_data : Modified file data to be sent while making the voice call
        """
        return file_data

    async def voice_init_conv_hook(conversation_id, body):
        """This method is invoked when a conversation is initiated for Voice

        Args:
            request : Request object sent while invoking the REST API
            body : JSON string body with details of the workflow response
        """
        logger.info("Voice init conversation hook called")
        return None

    async def voice_end_conv_hook(conversation_id, request=None, activity=None):
        """This method is invoked when the user disconnects from an ongoing voice call
           or the voice_conversation execution has timed out

        Args:
            conversation_id : The ending conversation's conversation id
            request : Request object sent while invoking the REST API
            activity : The activity object,
                       sent only when the voice_conversation is timed out
                       else it is None
        """
        return None

    async def sms_bot_start_conv_hook(body):
        """This method is invoked before a conversation is initiated for SMS
           Can be used to implement logic that would choose source (bot) numbers to send the SMS

        Args:
            body : JSON body with details of the dialog to be triggered
        """
        logger.info("SMS bot start conversation hook called")
        return None

    async def sms_bot_reply_hook(
        request, conversation_id, activity_id, end_conversation, response_list
    ):
        """This method is invoked after the SMS has been sent a list of responses

        Args:
            request: Acitivity object
            conversation_id: The conversation ID
            activity_id:
            end_conversation: Boolean flag to mark end of SMS conversation
                              (Set from the dialog designer - conversation state)
            response_list: A dictonary with key : message number and value : HttpResponse
        """
        logger.info("SMS bot reply hook called")
        return None

    async def whatsapp_data_channel(flow_data):
        """This method is invoked inside whatsapp/data-channel view. This is used by
           WhatsApp flows using data-exchange button to fetch data dynamically from
           the data-channel during a flow.

        Args:
            flow_data (dict): data sent by the flow in the request
                format: {
                    "version": "3.0",
                    "action": "data_exchange",
                    "screen": "SCREEN_NAME",
                    "data": {
                        "key1": "value1",
                        "key2": "value2"
                    },
                    "flow_token": "UNIQUE_FLOW_TOKEN"
                }

        Returns:
            dict: response_data that you want to return in the data-channel response
                format: {
                    "version": "3.0",
                    "screen": "SCREEN_NAME",
                    "data": {
                        "key1": "value1",
                        "key2": "value2"
                    },
                }
        """
        logger.info(f"First WhatsApp Flows Request data - {flow_data}")
        if flow_data.get("action") == "ping":
            response_data = {"version": "3.0", "data": {"status": "active"}}
        
        elif flow_data["screen"] == "Leave":

            logger.info(f"Leave screen")
            leavetype = flow_data["data"]["leavetype"]
            checktype = str(flow_data["data"]["check"])
            #logger.info(f"Json leavetype : {leavetype}")
            from datetime import datetime, timedelta

            # Get today's date
            today = datetime.now().date()
            # Subtract one day to get yesterday
            yesterday = today - timedelta(days=1)
            logger.info(f"checkpoint1------")
            # Check if the leave type is valid
            
            #logger.info(f"valid leave type- {leavetype}")
            
            if checktype == "type":
                response_data = {
                    "version": "3.0",
                    "screen": "Leave",
                    "data": {
                        "leavetype":leavetype,
                        "yesterday_date":yesterday.strftime('%Y-%m-%d'),
                        "max_date":today.strftime('%Y-%m-%d'),
                        "min_date":today.strftime('%Y-%m-%d') 
                    },
                }
                # return fail screen
            elif checktype == "details":
                relation = flow_data["data"].get("relation","NA")
                if relation == "1":
                    relation = "Husband"
                if relation == "2":
                    relation = "Wife"
                if relation == "3":
                    relation = "Father"
                if relation == "4":
                    relation = "Mother"
                if relation == "5":
                    relation = "Father in Law"
                if relation == "6":
                    realtion = "Mother in Law"
                if relation == "7":
                    relation = "Son"
                if relation == "8":
                    relation =  "Daughter"
                if relation == "9":
                    relation = "Brother"
                if relation == "10":
                    relation = "Sister"

                logger.info(f"leavetype- {leavetype}")
                child_dob = flow_data["data"].get("child_dob","NA")
                compoff_date = flow_data["data"].get("compoff_date","NA")
                logger.info(f"compoff_date data - {compoff_date}")
                child = flow_data["data"].get("child","NA")

                maternity_start_date = flow_data["data"].get("maternity_start_date","NA")
                maternity_end_date = flow_data["data"].get("maternity_end_date","NA")
                bereavement_start_date = flow_data["data"].get("bereavement_start_date","NA")
                bereavement_end_date = flow_data["data"].get("bereavement_end_date","NA")
                bereavement_name = flow_data["data"].get("bereavement_name","NA")
                #comments=flow_data["data"].get("comments","NA")#test
                maternity_comment= flow_data["data"].get("maternity_comment","NA")
                bereavement_comment= flow_data["data"].get("bereavement_comment","NA")
                paternity_comment= flow_data["data"].get("paternity_comment","NA")
                compoff_comment= flow_data["data"].get("compoff_comment","NA")
                mandatory_comment= flow_data["data"].get("mandatory_comment","NA")
                marriage_comment= flow_data["data"].get("marriage_comment","NA")
                casual_sick_comment= flow_data["data"].get("casual_sick_comment","NA")
                earned_comment= flow_data["data"].get("earned_comment","NA")

                paternity_start_date = flow_data["data"].get("paternity_start_date","NA")
                paternity_end_date = flow_data["data"].get("paternity_end_date","NA")

                compoff_start_date = flow_data["data"].get("compoff_start_date","NA")
                compoff_end_date = flow_data["data"].get("compoff_end_date","NA")
                mandatory_start_date = flow_data["data"].get("mandatory_start_date","NA")
                mandatory_end_date = flow_data["data"].get("mandatory_end_date","NA")
                marriage_start_date = flow_data["data"].get("marriage_start_date","NA")

                marriage_end_date = flow_data["data"].get("marriage_end_date","NA")
                casual_sick_start_date = flow_data["data"].get("casual_sick_start_date","NA")
                casual_sick_end_date = flow_data["data"].get("casual_sick_end_date","NA")
                earned_start_date = flow_data["data"].get("earned_start_date","NA")
                earned_end_date = flow_data["data"].get("earned_end_date","NA")

                

                leave_limits = {
                    "Bereavement Leave": 3,  # Exactly 3 days
                    "Paternity Leave": 5,    # Exactly 5 days
                    "Marriage Leave": 6,
                    "Maternity Leave":182,
                    "Mandatory Leave":7    # Exactly 7 days
                }
                logger.info(f"checkpoint2------")

                #logger.info(f"valid leave type- {leavetype}")
                # Mapping leave types to their corresponding start and end dates
                leave_date_map = {
                    "Bereavement Leave": (bereavement_start_date, bereavement_end_date),
                    "Paternity Leave": (paternity_start_date, paternity_end_date),
                    "Marriage Leave": (marriage_start_date, marriage_end_date),
                    "Earned Leave": (earned_start_date, earned_end_date),
                    "Casual/Sick Leave": (casual_sick_start_date, casual_sick_end_date),
                    "Compensatory Off": (compoff_start_date, compoff_end_date),
                    "Mandatory Leave": (mandatory_start_date, mandatory_end_date),
                    "Maternity Leave": (maternity_start_date, maternity_end_date),
                    #"comments":(comments)
                }
                logger.info(f"Leave date map: {leave_date_map}")
                # Pick correct dates for the leave type
                start_date_str, end_date_str = leave_date_map.get(leavetype, (None, None))

                # Convert to datetime.date
                start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()
                end_date = datetime.strptime(end_date_str, "%Y-%m-%d").date()
                date_difference = 0
                current_date = start_date

                while current_date <= end_date:
                    # For Maternity Leave → count ALL days (no skipping)
                    if leavetype == "Maternity Leave":
                        date_difference += 1

                    # For all other leave types → skip Saturday & Sunday
                    else:
                        if current_date.weekday() < 5:  # Monday=0 ... Friday=5
                            date_difference += 1

                    current_date += timedelta(days=1)
                    # if current_date.weekday() < 5:
                    #     date_difference += 1
                    # current_date += timedelta(days=1)

                # exact_limit = leave_limits[leavetype]
                if (leavetype == "Bereavement Leave" and date_difference == 3) or \
                    (leavetype == "Paternity Leave" and date_difference == 5) or \
                    (leavetype == "Maternity Leave" and date_difference == 182) or \
                    (leavetype == "Mandatory Leave" and date_difference == 7) or \
                    (leavetype == "Earned Leave") or \
                    (leavetype == "Casual/Sick Leave") or \
                    (leavetype == "Compensatory Off") or \
                    (leavetype == "Marriage Leave" and date_difference == 6):

                
                    response_data = {
                        "version": "3.0",
                        "screen": "Leave_Summary",
                        "data": {
                            "leavetype":leavetype,
                            
                            "yesterday_date":yesterday.strftime('%Y-%m-%d'),
                            "max_date":today.strftime('%Y-%m-%d'),
                            "min_date":today.strftime('%Y-%m-%d'),
                            "relation":relation,
                            "child_dob":child_dob,
                            "child":child,
                            "compoff_date":compoff_date,
                            "maternity_start_date":maternity_start_date,
                            "maternity_end_date":maternity_end_date,
                            "bereavement_start_date":bereavement_start_date,
                            "bereavement_end_date":bereavement_end_date,
                            "paternity_start_date":paternity_start_date,
                            "paternity_end_date":paternity_end_date,
                            "compoff_start_date":compoff_start_date,
                            "compoff_end_date":compoff_end_date,
                            "mandatory_start_date":mandatory_start_date,
                            "mandatory_end_date":mandatory_end_date,
                            "marriage_start_date":marriage_start_date,
                            "marriage_end_date":marriage_end_date,
                            "casual_sick_start_date":casual_sick_start_date,
                            "casual_sick_end_date":casual_sick_end_date,
                            "earned_start_date":earned_start_date,
                            "earned_end_date":earned_end_date,
                            "bereavement_name":bereavement_name,
                            "maternity_comment": maternity_comment,
                            "bereavement_comment": bereavement_comment,
                            "paternity_comment": paternity_comment,
                            "compoff_comment": compoff_comment,
                            "mandatory_comment": mandatory_comment,
                            "marriage_comment": marriage_comment,
                            "casual_sick_comment": casual_sick_comment,
                            "earned_comment": earned_comment,
                            },
                        }
                    #logger.info(f"Response Leave date map: {response_data}")
                else:
                    logger.info(f"In else- {leavetype}")
                    response_data = {
                    "version": "3.0",
                    "screen": "Leave_Fail",
                    "data": {
                        "leavetype":leavetype
                    },
                }
                    
        elif flow_data["screen"] == "Attendance":
            attendtype = flow_data["data"].get("attendtype","NA")
            On_Duty_On_Tour_R_start = flow_data["data"].get("On_Duty_On_Tour_R_start","NA")
            On_Duty_On_Tour_R_end = flow_data["data"].get("On_Duty_On_Tour_R_end","NA")
            Forgot_Unable_to_Login_start = flow_data["data"].get("Forgot_Unable_to_Login_start","NA")
            Forgot_Unable_to_Login_end = flow_data["data"].get("Forgot_Unable_to_Login_end","NA")
            from datetime import datetime, timedelta
            # Get today's date
            today = datetime.now().date()
            # Subtract one day to get yesterday
            yesterday = today - timedelta(days=1)
            response_data = {
                "version": "3.0",
                "screen": "Attendance",
                "data": {
                    "max_date":yesterday.strftime('%Y-%m-%d'),
                    "attendtype":attendtype,
                    "On_Duty_On_Tour_R_start":On_Duty_On_Tour_R_start,
                    "On_Duty_On_Tour_R_end":On_Duty_On_Tour_R_end,
                    "Forgot_Unable_to_Login_start":Forgot_Unable_to_Login_start,
                    "Forgot_Unable_to_Login_end":Forgot_Unable_to_Login_end

                },
            } 
            logger.info(f"Response attendance : {response_data}")
        
        elif flow_data["screen"]=="FORMsixty_REQUEST" or flow_data["screen"]=="FORMsixty_ValidateRequest":
            fina_year = flow_data["data"].get("fina_year","NA")
            pan_number = flow_data["data"].get("pan_number","NA")
            #ftype=flow_data["data"].get("ftype","NA")
            import re
            logger.info(f'fina year{fina_year}')
            logger.info(f'pan number{pan_number}')
            import re
 
            pan_number = pan_number.strip() if pan_number else ""
            
            # Regex: only alphanumeric (no special characters)
            pan_alphanumeric_pattern = re.compile(r'^[A-Za-z0-9]+$')
            
            if pan_number and pan_alphanumeric_pattern.match(pan_number):
            #pattern=r'^[a-zA-Z0-9]*$'
            #if re.fullmatch(pattern, pan_number):
            #if ftype == "details":
                response_data = {
                    "version": "3.0",
                    "screen": "FORMsixty_REVIEW",
                    "data": {
                        "fina_year":fina_year,
                        "pan_number":pan_number,
                    },
            
                }
            else:
                response_data = {
                    "version": "3.0",
                    "screen": "FORMsixty_ValidateRequest",
                    "data": {
                        "fina_year":fina_year,
                        "pan_number":pan_number,
                    },
            
                }
            logger.info(f'response_data:{response_data}')
            

        elif flow_data["screen"] == "HL_Verification":
            from datetime import datetime, timedelta
            # Get today's date
            today = datetime.now().date()
            # Subtract one day to get yesterday
            yesterday = today - timedelta(days=1)
            response_data = {
                "version": "3.0",
                "screen": "HL_Verification",
                "data": {
                    "paternity_start_date":yesterday.strftime('%Y-%m-%d')
                },
            } 
        #logger.info(f"WhatsApp Flows Response data - {response_data}")
        #logger.info(f"WhatsApp Flows Response data - {response_data}")
        return response_data

    async def custom_schedules():
        """This method allows to add any custom schedules to chatbot-webservice.
 
        Returns:
            List of Schedule objects to be added
        """
        return [
            Schedule(
                function="custom.schedules.FeedbackSchedule.feedback_reminder",
                trigger=ScheduleTrigger.TRIGGER_INTERVAL,
                minutes=1,
                name="Feedback Reminder Schedule",
                is_local_schedule=False,
                start_date=timezone.now(),
                timezone=str(timezone.now().tzinfo),
            )
        ]
