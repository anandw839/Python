import json
import logging
from botbuilder.core import TurnContext
from botbuilder.core.teams import TeamsInfo
from aistudiobot.aistudio.utils.constants import Constants
from django.apps import apps
from aistudiobot.aistudio.utils.common import CommonUtils
from common.http_utils import HTTPUtils
from requests.auth import HTTPBasicAuth

from aistudiobot.aistudio.dialog.state import (
    AIStudioConvState
)
from datetime import datetime
logger = logging.getLogger(__name__)
import datetime

class Custom_Bot_Helper:
    @staticmethod
    async def get_mobilenumber(
        context: TurnContext,
        aistudio_conv_state: AIStudioConvState,
    ):

        bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
        conv_state = bot_app.conv_state
        aistudio_conv_state = await AIStudioConvState.get(conv_state, context)
        if context.activity.channel_id == 'whatsapp':
            mobile_number = context.activity.from_property.id
        
            if len(mobile_number) == 12 and mobile_number.startswith("91"):
                # Remove the '91' prefix
                mobile_number = mobile_number[2:]

                aistudio_conv_state.add_conv_input_as_param("mobile_number", mobile_number)
        if context.activity.channel_id == 'msteams':
            team_members = await TeamsInfo.get_members(context)
            for member in team_members:
                    conversation_reference = context.get_conversation_reference(
                        context.activity
                    )
            team_email = getattr(member,"email")
            aistudio_conv_state.add_conv_input_as_param("Team_EmailId", team_email)
            #aistudio_user_state.add_user_input_as_param("Team_EmailId", team_email)

    @staticmethod
    async def check_access(
        context: TurnContext,
        aistudio_conv_state: AIStudioConvState,
    ):

        bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
        conv_state = bot_app.conv_state
        aistudio_conv_state = await AIStudioConvState.get(conv_state, context)
        mobile_number = context.activity.from_property.id
           

        if len(mobile_number) == 12 and mobile_number.startswith("91"):
            # Remove the '91' prefix
            mobile_number = mobile_number[2:]
        credential = CommonUtils.get_credential("API_Cred")
        #7057819219
        username = credential.value1  # Fetch username from credentials
        password = credential.value2  # Fetch password from credentials
        emp_access = "false"
        try:
            url = ("https://api10.successfactors.com/odata/v2/PerPhone?"
                "$select=personIdExternal,phoneType,isPrimary,phoneNumber,personNav/personalInfoNav/firstName,"
                "personNav/personalInfoNav/lastName&$expand=personNav/personalInfoNav,personNav&"
                f"$filter=phoneNumber eq '{mobile_number}' and isPrimary eq true&$format=json")
            
            # Send GET request with basic authentication
            response = await HTTPUtils.http_get(url, auth=HTTPBasicAuth(username, password))
            #response = requests.get(url, auth=HTTPBasicAuth(username, password))
            
            if response.status_code == 200:
                # Parsing response data
                data = response.json()
                print("emP_response_json", response.json())
                if not data['d']['results']:
                    emp_id = "No employee details found for the provided phone number"
                    aistudio_conv_state.add_conv_input_as_param("emp_access", "false")

                else:
                    emp_id = response.json()['d']['results'][0]['personIdExternal']
                    emp_name =response.json()['d']['results'][0]['personNav']['personalInfoNav']['results'][0]['firstName']
                    first_name =response.json()['d']['results'][0]['personNav']['personalInfoNav']['results'][0]['firstName']
                    last_name =response.json()['d']['results'][0]['personNav']['personalInfoNav']['results'][0]['lastName']
                    full_name = first_name +" "+ last_name
                    aistudio_conv_state.add_conv_input_as_param("emp_access", "true")
                    aistudio_conv_state.add_conv_input_as_param("emp_id", emp_id)
                    aistudio_conv_state.add_conv_input_as_param("emp_name", emp_name)
                    aistudio_conv_state.add_conv_input_as_param("full_name", full_name)
                    await Custom_Bot_Helper.fetch_employee_details(context, aistudio_conv_state)
                
            else:
                print(f"Error: {response.status_code}")
                aistudio_conv_state.add_conv_input_as_param("emp_access", "false")
                return None
        
        except Exception as e:
            print(f"Error: An error occurred during the request: {e}")
            return None

    @staticmethod
    async def fetch_employee_details(
        context: TurnContext,
        aistudio_conv_state: AIStudioConvState
        
    ):
        bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
        conv_state = bot_app.conv_state
        aistudio_conv_state = await AIStudioConvState.get(conv_state, context)
        conv_params = aistudio_conv_state.get_conv_params()
        utterance = conv_params[Constants.UTTERANCE]

        conv_params = aistudio_conv_state.get_conv_params()
        emp_code=conv_params['emp_id']

        credential = CommonUtils.get_credential("API_Cred")
        username = credential.value1
        password = credential.value2

        try:
            url = (
                "https://api10.successfactors.com/odata/v2/User?"
                "$select=userId,firstName,lastName,empId,hireDate,username,jobTitle,"
                "empInfo/startDate,empInfo/personNav/homeAddressNavDEFLT/addressType,"
                "empInfo/personNav/homeAddressNavDEFLT/address1,"
                "empInfo/personNav/homeAddressNavDEFLT/address2,"
                "empInfo/personNav/homeAddressNavDEFLT/address3,"
                "empInfo/personNav/homeAddressNavDEFLT/address4,"
                "empInfo/personNav/homeAddressNavDEFLT/address5,"
                "empInfo/personNav/homeAddressNavDEFLT/city,"
                "empInfo/personNav/homeAddressNavDEFLT/country,"
                "empInfo/personNav/homeAddressNavDEFLT/state,"
                "empInfo/personNav/homeAddressNavDEFLT/zipCode,"
                "empInfo/jobInfoNav/businessUnit,"
                "empInfo/jobInfoNav/customString11,"
                "empInfo/jobInfoNav/jobTitle,empInfo/jobInfoNav/businessUnitNav/name_defaultValue,"
                "empInfo/jobInfoNav/businessUnitNav/name,"
                "empInfo/jobInfoNav/businessUnitNav/externalCode,"
                "empInfo/personNav/personalInfoNav/gender,"
                "empInfo/jobInfoNav/divisionNav/externalCode,"
                "empInfo/jobInfoNav/divisionNav/name,"
                "empInfo/jobInfoNav/divisionNav/name_defaultValue,"
                "empInfo/jobInfoNav/departmentNav/name,"
                "empInfo/jobInfoNav/departmentNav/name_defaultValue,"
                "empInfo/jobInfoNav/departmentNav/externalCode,"
                "empInfo/jobInfoNav/locationNav/externalCode,"
                "empInfo/jobInfoNav/locationNav/name,"
                "empInfo/jobInfoNav/customString1Nav/name,"
                "empInfo/jobInfoNav/managerId,empInfo/jobInfoNav/customString11Nav/picklistLabels/label,"
                "empInfo/jobInfoNav/employmentTypeNav/picklistLabels/label,"
                "empInfo/jobInfoNav/employeeClassNav/picklistLabels/label,"
                "empInfo/personNav/dateOfBirth,"
                "empInfo/personNav/personalInfoNav/maritalStatus,"
                "empInfo/personNav/personalInfoNav/customString4,"
                "empInfo/customDate1,"
                "empInfo/jobInfoNav/customString9,"
                "empInfo/jobInfoNav/customString10,"
                "empInfo/jobInfoNav/customString21,"
                "empInfo/personNav/emergencyContactNav/name,"
                "empInfo/personNav/emergencyContactNav/relationship,"
                "empInfo/personNav/emergencyContactNav/email,"
                "empInfo/personNav/emergencyContactNav/phone,"
                "empInfo/personNav/phoneNav/phoneNumber,"
                "empInfo/personNav/phoneNav/phoneType,"
                "empInfo/personNav/emailNav/emailType,"
                "empInfo/personNav/emailNav/emailAddress,"
                "empInfo/empJobRelationshipNav/relationshipType,"
                "empInfo/empJobRelationshipNav/relUserId"
                "&$expand=empInfo/personNav/homeAddressNavDEFLT,empInfo/personNav,"
                "empInfo,empInfo/jobInfoNav,empInfo/jobInfoNav/businessUnitNav,"
                "empInfo/personNav/personalInfoNav,empInfo/jobInfoNav/divisionNav,"
                "empInfo/jobInfoNav/departmentNav,empInfo/jobInfoNav/locationNav,"
                "empInfo/jobInfoNav/customString1Nav,empInfo/jobInfoNav/customString11Nav/picklistLabels,"
                "empInfo/jobInfoNav/customString11Nav,empInfo/jobInfoNav,"
                "empInfo,empInfo/jobInfoNav/employmentTypeNav/picklistLabels,"
                "empInfo/jobInfoNav/employmentTypeNav,empInfo/jobInfoNav/employeeClassNav/picklistLabels,"
                "empInfo/jobInfoNav/employeeClassNav,empInfo/personNav/emergencyContactNav,"
                "empInfo/personNav/phoneNav,empInfo/personNav/emailNav,empInfo/empJobRelationshipNav"
                f"&$filter=userId eq '{emp_code}'&$format=json"
            )
                    
            response = await HTTPUtils.http_get(url, auth=HTTPBasicAuth(username, password))
            aistudio_conv_state.add_conv_input_as_param("response", response)
            # aistudio_conv_state.add_dialog_input_as_param(dialog_name, "response", response)
            if response.status_code == 200:
                results = response.json()["d"]["results"]
                print(f"results--: {results}")
                if len(results) > 0:
                    print("success--:","true")
                    r = results[0]

                    # Basic fields
                    first_name = r.get("firstName") or "NA"
                    last_name = r.get("lastName") or "NA"

                    job_info = r["empInfo"]["jobInfoNav"]["results"][0]

                    designation = job_info.get("jobTitle") or "NA"
                    emp_code = r.get("empId") or "NA"

                    department = job_info["divisionNav"].get("name") or "NA"

                    # Hire date conversion
                    hiredate_raw = r.get("hireDate")
                    if hiredate_raw:
                        millis = int(hiredate_raw[6:-2])
                        seconds = millis / 1000.0
                        hiredate = datetime.datetime.fromtimestamp(seconds).strftime("%d-%m-%Y")
                    else:
                        hiredate = "NA"

                    function_name = job_info["businessUnitNav"].get("name") or "NA"

                    # Address details
                    data = r["empInfo"]["personNav"]["homeAddressNavDEFLT"]["results"]

                    presentAddress = {}
                    homeaddress = {}

                    for address in data:
                        if address["addressType"] == "present":
                            presentAddress = {
                                "address1": address.get("address1") or "",
                                "address2": address.get("address2") or "",
                                "address3": address.get("address3") or "",
                                "city": address.get("city") or "",
                                "state": address.get("state") or "",
                                "zipCode": address.get("zipCode") or "",
                                "country": address.get("country") or "",
                            }

                        if address["addressType"] == "home":
                            homeaddress = {
                                "address1": address.get("address1") or "",
                                "address2": address.get("address2") or "",
                                "address3": address.get("address3") or "",
                                "city": address.get("city") or "",
                                "state": address.get("state") or "",
                                "zipCode": address.get("zipCode") or "",
                                "country": address.get("country") or "",
                            }

                    # FIX 1: Date of Birth - CORRECTED
                    date_of_birth_raw = r.get("empInfo", {}).get("personNav", {}).get("dateOfBirth")
                    if date_of_birth_raw:
                        millis = int(date_of_birth_raw[6:-2])  # FIXED: was using hiredate_raw
                        seconds = millis / 1000.0
                        date_of_birth = datetime.datetime.fromtimestamp(seconds).strftime("%d-%m-%Y")
                    else:
                        date_of_birth = "NA"

                    subDepartment = job_info["departmentNav"].get("name") or "NA"
                    region = job_info["customString1Nav"].get("name") or "NA"
                    role = job_info.get("jobTitle") or "NA"
                    managerId = job_info.get("managerId") or "NA"
                    personal_info = (
                            r.get("empInfo", {})
                            .get("personNav", {})
                            .get("personalInfoNav", {})
                            .get("results", [])
                        )

                    gender = personal_info[0].get("gender") if personal_info else "NA"
                    marital_status = personal_info[0].get("maritalStatus") if personal_info else "NA"
                    # FIX 2: Relationships (ZHR + LVHR) - CORRECTED
                    rel_list = r.get("empInfo", {}).get("empJobRelationshipNav", {}).get("results", [])
                    relUserIdZHR = "NA"
                    relUserIdLVHR = "NA"

                    for rel in rel_list:
                        rel_type = rel.get("relationshipType")
                        if rel_type == "71982":
                            relUserIdZHR = rel.get("relUserId") or "NA"
                        elif rel_type == "71978":
                            relUserIdLVHR = rel.get("relUserId") or "NA"

                    # FIX 3: Email - CORRECTED (results is a list!)
                    email_results = r.get("empInfo", {}).get("personNav", {}).get("emailNav", {}).get("results", [])
                    if email_results and len(email_results) > 0:
                        email = email_results[0].get("emailAddress") or "NA"
                    else:
                        email = "NA"

                    # FIX 4: Phone Number - CORRECTED (results is a list!)
                    phone_results = r.get("empInfo", {}).get("personNav", {}).get("phoneNav", {}).get("results", [])
                    if phone_results and len(phone_results) > 0:
                        phoneNumber = phone_results[0].get("phoneNumber") or "NA"
                    else:
                        phoneNumber = "NA"

                    # Emergency contact details - CORRECTED
                    ec_list = r.get("empInfo", {}).get("personNav", {}).get("emergencyContactNav", {}).get("results", [])
                    emergency_contacts = {"wife_details": {}, "father_details": {}}

                    for ec in ec_list:
                        rel_code = ec.get("relationship")
                        if str(rel_code) == "70280":  # wife
                            emergency_contacts["wife_details"] = {
                                "name": ec.get("name") or "",
                                "relationship": "WIFE",
                                "phone": ec.get("phone") or "",
                                "email": ec.get("email") or ""
                            }
                        elif str(rel_code) == "70276":  # father
                            emergency_contacts["father_details"] = {
                                "name": ec.get("name") or "",
                                "relationship": "FATHER",
                                "phone": ec.get("phone") or "",
                                "email": ec.get("email") or ""
                            }

                    # Final personal details
                    personal_details = {
                        "full_name": first_name + " " + last_name,
                        "first_name": first_name,
                        "last_name": last_name,
                        "designation": designation,
                        "emp_code": emp_code,
                        "gender":gender,
                        "marital_status":marital_status,
                        "function_name": function_name,
                        "hire_date": hiredate,
                        "home_address": homeaddress,
                        "present_address": presentAddress,
                        "department": department,
                        "date_of_birth": date_of_birth,
                        "subDepartment": subDepartment,
                        "Lead_Vertical_HR_ID": relUserIdLVHR,
                        "ZHR_ID": relUserIdZHR,
                        "role": role,
                        "region": region,
                        "managerId": managerId,
                        "email": email,
                        "phoneNumber": phoneNumber,
                        "emergency_contacts": emergency_contacts,
                        "grade":"GB05A"
                    }
                    logger.info(f"personal_details - {personal_details}")
                    print("personal_details--",personal_details)
                    # aistudio_conv_state.add_dialog_input_as_param(dialog_name, "personal_details", personal_details)
                    aistudio_conv_state.add_conv_input_as_param("personal_details", personal_details)
                    aistudio_conv_state.add_conv_input_as_param("manager_id", managerId)
                    # return first_name, last_name, designation, emp_code, response.status_code

                else:
                    aistudio_conv_state.add_conv_input_as_param("personal_details", "No Personal details are available at this time")
                    # aistudio_conv_state.add_dialog_input_as_param(dialog_name, "details", "Apologies, our service is currently unavailable. Please try again after some time. Thank you for your patience!")

            else:
                print(f"Error: {response.status_code}")
                aistudio_conv_state.add_conv_input_as_param("personal_details", response.status_code)
                # aistudio_conv_state.add_dialog_input_as_param(dialog_name, "details", "Apologies, our service is currently unavailable. Please try again after some time. Thank you for your patience!")
                return None

        except Exception as e:
            print(f"Error: An error occurred during the request: {e}")
            aistudio_conv_state.add_conv_input_as_param("personal_details", "error")
            # aistudio_conv_state.add_dialog_input_as_param(dialog_name, "details", "Apologies, our service is currently unavailable. Please try again after some time. Thank you for your patience!")
            return None

   