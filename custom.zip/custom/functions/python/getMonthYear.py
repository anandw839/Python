from aistudiobot.aistudio.dialog.state import (
    AIStudioConvState,
    AIStudioUserState,
)
import logging
from botbuilder.core import TurnContext
from aistudiobot.aistudio.utils.constants import Constants

import json
from datetime import datetime
from dateutil.relativedelta import relativedelta
from custom.functions.helpers.prompt_helpers import (
    pick_month_year,
    guess_financial_year,
    guess_month
    )
logger = logging.getLogger(__name__)

async def get_month_year(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
    ):
    logger.info("get_month_year is triggered.")
    
    conv_params = aistudio_conv_state.get_conv_params()
    utterance = conv_params[Constants.UTTERANCE]
    logger.info("Payslip utterance---%s",utterance)
   
    details = await pick_month_year(utterance)
    print("details---",details)
    #logger.info("details---",details)
    month_json = json.loads(
        details.strip().strip("```").strip().replace("json", "").strip()
    )
    year= month_json.get("year", "None")#test
    month = month_json.get("month", "None")
    def normalize(v):
        return "None" if v in (None, "", "NA") else v

    year = normalize(month_json.get("year"))
    month = normalize(month_json.get("month"))
    
    if month.lower() not in [
        "jan",
        "january",
        "feb",
        "february",
        "mar",
        "march",
        "apr",
        "april",
        "may",
        "jun",
        "june",
        "jul",
        "july",
        "aug",
        "august",
        "sep",
        "september",
        "oct",
        "october",
        "nov",
        "november",
        "dec",
        "december",
    ]:
        month = "None"

    if str(year).strip().lower() in ["none", "", "null"] and month not in ["None", None, ""]:
       year = str(datetime.now().year)
       logger.info("get month year function: %s",year)
    
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "month", month)
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "year", year)

async def check_month(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
    ):
    
    conv_params = aistudio_conv_state.get_conv_params()
    # utterance = conv_params[Constants.UTTERANCE]
    # print("Payslip utterance---",utterance)
    month = aistudio_conv_state.get_dialog_input_as_param(
        dialog_name, "month"
    ) or aistudio_conv_state.get_dialog_input_as_param("pay_slip", "month")
    #logger.info("Month variable %s",month)
   
    details = await guess_month(month)
    logger.info("Check month details---%s",details)

    month_json = json.loads(
        details.strip().strip("```").strip().replace("json", "").strip()
    )

    logger.info(f"Month JSON {month_json}")
   
    year= month_json.get("year", "None")
    logger.info("Year : %s",year)
    month = month_json.get("month", "None")
    def normalize(v):
        return "None" if v in (None, "", "NA") else v

    year = normalize(month_json.get("year")) #test
    month = normalize(month_json.get("month"))
    
    
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "month", month)
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "year", year)#test


async def generate_last_three_months_json(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
    ):
    # Current month
    now = datetime.now()

    # Month abbreviations & full names
    month_abbr = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"]
    month_full = ["January","February","March","April","May","June",
                  "July","August","September","October","November","December"]

    buttons = []

    # Generate last 3 months
    for i in range(1, 4):
        month_date = now - relativedelta(months=i)
        abbr = month_abbr[month_date.month - 1]
        full = month_full[month_date.month - 1]
        year_int = month_date.year
        logger.info(f"generate lat three months year: {year_int}")
        year_str =str(year_int)

        button = {
            "type": "postBack",
            "title": json.dumps({"title": full, "description": full}),
            "value": json.dumps({
                "__trigger_aistudio_dialog__": "payslip",
                "month": abbr+" "+year_str ,
                
                "query": "${conv.__utterance__}"
            })
        }
        buttons.append(button)

    result = {
        "buttons": buttons,
        "text": json.dumps({"text": "Please select month👇", "button": "Tech Services"}),
        "year":year_int
    }
    final_json = json.dumps(result, indent=2, ensure_ascii=False)
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "json",final_json)
    logger.info("generate last three month json %s",final_json)
    # return json.dumps(result, indent=2)

async def pick_financial_year(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
    ):
    
    conv_params = aistudio_conv_state.get_conv_params()
    utterance = conv_params[Constants.UTTERANCE]
    # from custom.helpers.prompt_helpers import (
    #     pick_financial_year,
    # )
    details = await guess_financial_year(utterance)
    year_json = json.loads(
        details.strip().strip("```").strip().replace("json", "").strip()
    )
    logger.info("details : ",details)
    year= year_json.get("year", "None")
    if year == "None" or year is None or year == "":
        now = datetime.now()
        current_year = now.year
        current_month = now.month
    
        # Financial year starts in April
        
        start_year = current_year - 1
        end_year = current_year
        start_year2 = start_year - 1 #testing year 2
        end_year2= end_year - 1 #testing year 2
        
        #year =end_year
        year1 = f"{start_year}-{end_year}"
        logger.info(year1)
        year2 = f"{start_year2}-{end_year2}" #testing year 2
        logger.info("second year will be: ",year1)

    #aistudio_conv_state.add_dialog_input_as_param(dialog_name, "year", year)
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "financial_year", year1)
    aistudio_conv_state.add_dialog_input_as_param(dialog_name, "financial_year2", year2) #testing year 2
 