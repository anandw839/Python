from botbuilder.core import TurnContext
from aistudiobot.aistudio.dialog.state import AIStudioConvState, AIStudioUserState
from aistudiobot.aistudio.utils.common import CommonUtils
from django.conf import settings
from aistudiobot.models import ChatConversation, ChatSession
from django.apps import apps
from aistudiobot.aistudio.utils.constants import Constants
# from aistudiobot.helpers.genai_km_helper import GenAIKMHelper
from custom.functions.helpers.genai_km_helper import GenAIKMHelper
import re
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging
import json
import uuid
import random
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import msal
import requests
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from common.http_utils import HTTPUtils
from botbuilder.core.teams import TeamsInfo
import markdown


async def clear_history(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
):
    # This function is used to clear user history
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
    )
    user_history = list(aistudio_conv_state.get_conv_input_as_param("history") or [])
    
    logging.info("User history ->",user_history)
    if len(user_history) != 0:
        user_history.clear()
        # Update the conversation state with the cleared history
        aistudio_conv_state.add_conv_input_as_param("history", user_history)
        logging.info("User history cleared successfully.")
    else:
        logging.info("User history is already empty.")

async def calling_genai_km_helper(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
):

    from asgiref.sync import sync_to_async
    # from custom.functions.python.response import save_response
    from aistudiobot.storecon import log_and_send_activity

    # This function calls genai km helper
    logger = logging.getLogger(__name__)

    @sync_to_async(thread_sensitive=settings.THREAD_SENSITIVE)
    def populate_db_hashmap(conv_id):
        try:
            db_hashmap = apps.get_app_config(Constants.AISTUDIOBOT).db_hashmap
            chat_sessions = ChatSession.objects.filter(
                bot_framework_conversation_id=conv_id
            ).order_by("-start_time")
            if chat_sessions.exists():
                chat_session = chat_sessions[0]
                db_hashmap["chat_session"][conv_id] = chat_session
                chat_conversations = ChatConversation.objects.filter(
                    chat_session=chat_session, end_time__isnull=True
                )
                if chat_conversations.exists():
                    chat_conversation = chat_conversations[0]
                    db_hashmap["chat_conversation"][conv_id] = {
                        "object": chat_conversation,
                        "save": False,
                    }
        except Exception as e:
            logger.error(f"Error populating DB hashmap: {e}")
            raise

    # Getting user question, user history, and tag
    try:
        utterance = (
            aistudio_conv_state.get_dialog_input_as_param(dialog_name, "utterance")
            or context.activity.text
        )
        user_history = aistudio_conv_state.get_conv_input_as_param("history") or []
        logging.info(f"User history2 ->",user_history)
        streaming = (
            aistudio_conv_state.get_conv_input_as_param("streaming")
            or "Yes(Streaming On)"
        )
    except KeyError as e:
        logger.error(f"Missing conversation  parameter: {e}")
        return

    # Querying the KM Helper

    if context.activity.attachments:
        await log_and_send_activity(
            context, "This bot is not configured to handle attachments.", handoff=False
        )
        return
    try:
        logging.info(f"User history3 ->",user_history)
        km_responses = await GenAIKMHelper.query(
            context,
            aistudio_conv_state,
            aistudio_user_state,
            utterance,
            streaming == "Yes(Streaming On)",
            user_history,
            [],
        )
        logging.info("km_responses--------------------------->",km_responses)
    except Exception as e:
        logger.error(
            f"Error invoking GenAIKMHelper.query: {e}"
            f"utterance : {utterance}"
            f"user history : {user_history}"
        )

    # Processing the KM response
    found_answer = False
    print("km response:--------",km_responses)
    if km_responses is not None:
        from bs4 import BeautifulSoup

        latest_data = km_responses["answer"]
        

        # Remove source tags like [S1], [S2], etc.
        latest_data = re.sub(r"\[S\d+\]", "", latest_data)

        # Strip all HTML, scripts, and SVGs for clean plain text
        soup = BeautifulSoup(latest_data, "html.parser")
        text_only = soup.get_text(separator="\n").strip()

        found_answer = True

        # Add cleaned text to conversation state
        aistudio_conv_state.add_dialog_input_as_param(dialog_name, "km_response_answer", text_only)
        aistudio_conv_state.add_dialog_input_as_param(dialog_name, "trigger", "No")

        # Optional: preserve raw links for WhatsApp if needed
        # Consider extracting <a href> links separately if you want to show "References" at the end

        # Populate the DB hashmap for state management
        try:
            await populate_db_hashmap(context.activity.conversation.id)
        except Exception as e:
            logger.error(
                f"Error in populate_db_hashmap: {e}"
                f" | conversation id: {context.activity.conversation.id}"
                f" | context: {context}"
                f" | KM Answer: {latest_data}"
            )
    else:
        latest_data = None
        logging.error("km_responses is None. Unable to access 'answer'.")

    # Check for <IDONTKNOW /> fallback flag
    pattern = r"<IDONTKNOW\s*/>"
    if latest_data:
        match = re.search(pattern, latest_data, re.IGNORECASE)
        if match:
            found_answer = False
            trigger = "Yes"
            aistudio_conv_state.add_conv_input_as_param("user_question", utterance)
            aistudio_conv_state.add_conv_input_as_param(
                "modified_query", km_responses.get("query")
            )
            aistudio_conv_state.add_dialog_input_as_param(dialog_name, "trigger", "Yes")
            aistudio_conv_state.add_conv_input_as_param("email_number", 0)
    else:
        logging.error("Latest data is also None")

    # Maintain rolling user history (limited to last 5)
    if len(user_history) > 5:
        user_history.pop(0)

    user_history.append({"user": utterance, "assistant": text_only})
    logging.info("User history4 ->",user_history)
    aistudio_conv_state.add_conv_input_as_param("history", user_history)

    # (Optional) You can uncomment and adapt this block for logging or storing cleaned output
    # try:
    #     await save_response(km_responses, user_history, context, aistudio_conv_state, found_answer)
    # except Exception as e:
    #     logger.error(f"Error saving KM response: {e}")

    logger.info("KM response successfully handled and ready for WhatsApp.")


async def test_km_api_with_custom_system_prompt(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
):
    # Get cognibot from Django apps configuration
    bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
    cognibot = bot_app.cognibot

    # Get the GenAI settings for current skill
    from aistudiobot.helpers.bot_helper import BotHelper
    from copy import deepcopy
    from botbuilder.core import MessageFactory, TurnContext
    from custom.functions.python.custom import fetch_employee_details

    conv_params = aistudio_conv_state.get_conv_params()
    user_params = aistudio_user_state.get_user_params()
    skill = conv_params.get(Constants.SKILL)
    skill_settings = cognibot.skill_settings_map.get(skill)
    if not skill_settings.km_enabled:
        return "KM Setting for skill not enabled"
    km_genai = BotHelper.get_km_details(skill_settings, cognibot.km_settings_list)

    cipher = CommonUtils.get_cipher()
    km_genai_copy = deepcopy(km_genai)
    km_genai_copy.km_genai.km_project_secret = cipher.decrypt(
        km_genai.km_genai.km_project_secret
    )
    km_url = km_genai_copy.km_genai.url + "/api"

    
    personal_details = aistudio_conv_state.get_dialog_input_as_param(dialog_name, "details_test_km")
    # logging.info("The personal detials Shivam in test km is:",personal_details)
    activity = MessageFactory.text(personal_details)
    activity.conversation = context.activity.conversation
    response = await context.send_activity(activity)

    prompt = f"""

         Provide me the response based on the sources provided below
        * Always provide me response in plain text.
        * Don't exceed the word limit of 3500.
        * If employee is asking for any personal information  then use the personal information  provided to form the authentic and data based response.
        * If input query is only emoji then respond with This bot is not configured to handle emojis.  
        The personal details of this users is:
        ```
        {personal_details}

        """
    system_prompt = (
    
         prompt+   
        str("The provided sources are:```{sources}```")

    )

    # Authenticate with KM Service
    token = await GenAIKMHelper.authenticate(
        apps.get_app_config(Constants.AISTUDIOBOT), skill, km_genai_copy
    )
    if not token:
        return {"error": "Failed to authenticate with KM Service"}

    # Prepare test query and history
    # conv_params = aistudio_conv_state.get_conv_params()
    # utterance = conv_params[Constants.UTTERANCE]
    #How much leave I can take respond based on my personal information that you have.
    test_query = "M i eligible for 15000 hotel room booking in chennai"
    test_history = []

    # Prepare filters (optional - based on region/tag)
    test_filters = []
    region = conv_params.get("Regions") or "India"

    # Prepare custom payload with system_prompt in overrides
    history_copy = deepcopy(test_history)
    history_copy.append({"user": test_query})

    payload = {
        "history": history_copy,
        "filters": test_filters,
        "debug": True,  # Enable debug to get thoughts and extra info
        "overrides": {
            "retrieval_mode": "vectors",
            "system_prompt": system_prompt,  # Custom system prompt
        },
    }

    # Make direct API call to KM Service with custom overrides
    try:
        headers = {"Authorization": f"Bearer {token}"}
        url = f"{km_url}/query"

        km_response = await HTTPUtils.http_post(
            url, headers=headers, data=json.dumps(payload)
        )

        if km_response.status_code != 200:
            return {
                "success": False,
                "error": f"KM API returned status {km_response.status_code}",
                "details": km_response.text,
            }

        response = km_response.json()

        # Check for error in response
        if "error" in response:
            return {
                "success": False,
                "error": response.get("error").get("message", "Unknown error"),
            }

        # Validate response structure
        if "answer" in response:
            result = {
                "success": True,
                "answer": response.get("answer"),
                "query": response.get("query"),
                "data_points": response.get("data_points", []),
                "tokens": response.get("tokens", {}),
                "system_prompt_used": system_prompt,
            }

            # If debug mode, include additional info
            if "thoughts" in response:
                result["thoughts"] = response.get("thoughts")
                result["query_points"] = response.get("query_points", [])

            activity = MessageFactory.text(response.get("answer"))
            activity.conversation = context.activity.conversation
            response = await context.send_activity(activity)

            return result
        else:
            return {
                "success": False,
                "error": "Invalid response structure from KM Service",
                "raw_response": response,
            }

    except Exception as e:
        print(f"Error during KM API test with custom system prompt: {e}")
        return {"success": False, "error": str(e)}


