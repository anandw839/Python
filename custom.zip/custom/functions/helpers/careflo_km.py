import json
import logging
import re
from html.parser import HTMLParser

from botbuilder.core import TurnContext
from django.conf import settings

from aistudiobot.aistudio.dialog.state import (
    AIStudioConvState,
    AIStudioUserState,
)
from aistudiobot.aistudio.utils.common import AIStudioFile
from aistudiobot.aistudio.utils.constants import Constants
from aistudiobot.helpers.bot_helper import BotHelper
from common.constants import HTTPConstants
from common.http_utils import HTTPUtils

logger = logging.getLogger(__name__)

KM_BASE_URL = "http://localhost:8001"


async def chat_completion(
    context: TurnContext,
    dialog_name: str,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
):
    conv_params = aistudio_conv_state.get_conv_params()
    utterance = conv_params[Constants.UTTERANCE]

    json_data = {
        "overrides": {
            "retrieval_mode": "hybrid",
            "semantic_ranker": True,
            "semantic_captions": False,
            "top": 3,
            "suggest_followup_questions": False,
        },
    }

    # Add previous history and user utterenance
    history: list[dict] = aistudio_conv_state.get_conv_input_as_param("history") or []
    history.append({"user": utterance})

    # num_last_messages = NUM_TURNS_RETAINED or None

    # if num_last_messages:
    #     history = history[-num_last_messages - 1 :]

    json_data["history"] = history

    logger.info(f"Chat completion request : {json_data}")

    token = await get_token(conv_params)

    headers = {
        HTTPConstants.CONTENT_TYPE: HTTPConstants.APPLICATION_JSON,
        HTTPConstants.AUTHORIZATION: f"Bearer {token}",
    }

    response = await HTTPUtils.http_post(
        KM_BASE_URL + "/api/query",
        headers=headers,
        data=json.dumps(json_data),
    )

    if response.status_code == 200:
        res_json = response.json()
        answer, citations = get_citations(res_json["answer"])
        km_card = create_km_card(answer, citations)
        aistudio_conv_state.add_conv_input_as_param("km_card", km_card)

        history[-1]["assistant"] = res_json["answer"]
        aistudio_conv_state.add_conv_input_as_param("history", history)
        return True
    else:
        logger.error(f"Error in chat completion : {response.status_code}, {response}")
        aistudio_conv_state.add_conv_input_as_param("km_card", "null")
        return None


async def get_token(conv_params):
    if token := conv_params.get("token"):
        return token
    else:
        headers = {
            "Project-Id": "a39c457c-2808-430e-a444-3e5fae6c43a7",
            "Project-Secret": "ZmP-GIIeRr7P",
        }
        response = await HTTPUtils.http_get(KM_BASE_URL + "/api/token", headers=headers)

        token = response.json().get("token")

        conv_params["token"] = token

        return token


def get_citations(km_answer: str):
    # Regular expression to find citations in the format [<filename>.pdf]
    citation_pattern = r"\[([^\]]+\.pdf)\]"
    citations = re.findall(citation_pattern, km_answer)
    citation_dict = {}
    for i, citation in enumerate(citations, start=1):
        citation_number = f"[{i}]"
        citation_dict[str(i)] = citation
        km_answer = km_answer.replace(f"[{citation}]", citation_number)

    return km_answer, citation_dict


def create_km_card(km_answer, citations: dict = {}):
    km_card = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [{"type": "Container", "items": []}],
    }

    km_answer = km_answer.replace("\n", "")

    pattern = re.compile(r"(<table>.*?</table>)")

    result = pattern.split(km_answer)
    # Filter out empty strings from the result
    result = [item for item in result if item.strip()]

    # Display the output
    for value in result:
        logger.info(f"Creating card :: {value}")

        if value.startswith("<table>"):
            km_card["body"][0]["items"].append(convert_table_data(value))
        else:
            km_card["body"][0]["items"].append(
                {
                    "type": "RichTextBlock",
                    "inlines": [{"type": "TextRun", "text": value}],
                }
            )

    for key, value in citations.items():
        file_url = f"{KM_BASE_URL}/content/{value}"

        km_card["body"].append(
            {
                "type": "ActionSet",
                "actions": [
                    {
                        "type": "Action.OpenUrl",
                        "title": f"{key}. {value}",
                        "url": file_url,
                    }
                ],
            }
        )

    logger.info(f"KM card : {json.dumps(km_card)}")
    return json.dumps(km_card)


class TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_table = False
        self.in_row = False
        self.in_header = False
        self.headers = []
        self.rows = []
        self.current_row = []

    def handle_starttag(self, tag, attrs):
        if tag == "table":
            self.in_table = True
        elif tag == "tr":
            self.in_row = True
        elif tag == "th":
            self.in_header = True
            self.current_row.append(
                {
                    "type": "TableCell",
                    "items": [{"type": "TextBlock", "text": "", "wrap": "true"}],
                }
            )
        elif tag == "td":
            self.current_row.append(
                {
                    "type": "TableCell",
                    "items": [{"type": "TextBlock", "text": "", "wrap": "true"}],
                }
            )

    def handle_endtag(self, tag):
        if tag == "table":
            self.in_table = False
        elif tag == "tr":
            if self.in_header:
                self.headers.append({"type": "TableRow", "cells": self.current_row})
                self.in_header = False
            else:
                self.rows.append({"type": "TableRow", "cells": self.current_row})
            self.current_row = []
            self.in_row = False
        elif tag == "th":
            if self.in_header:
                self.headers = self.current_row
                self.in_header = False

    def handle_data(self, data):
        if self.in_row and self.current_row:
            self.current_row[-1]["items"][0]["text"] += data


def convert_table_data(data):
    logger.info(f"Data for conversion : {data}")
    parser = TableParser()
    parser.feed(data)

    json_data = {
        "type": "Table",
        "columns": [{"width": "1"} for _ in parser.headers],
        "rows": parser.rows,
    }

    return json_data
