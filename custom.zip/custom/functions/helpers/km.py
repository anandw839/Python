import logging
import os
import json
from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.vectorstores.redis import Redis
from langchain.embeddings import OpenAIEmbeddings

from custom.functions.helpers.custom import personal_details

logger = logging.getLogger(__name__)

logger.info("My Personal Details in KM: %s",personal_details)


DOCUMENT_URL = ""

async def predict(query, additional_info=""):
    embeddings = OpenAIEmbeddings()
    rds = Redis.from_existing_index(embeddings, index_name="balic")
    results = rds.similarity_search(query)
    results_json = json.dumps(
        list(
            map(
                lambda result: {"content": result.page_content, **result.metadata},
                results,
            )
        )
    )
    try:
        prompt = ChatPromptTemplate.from_template(
            """
           You are a Knowledge Retrieval system which answers the question raised by the user by looking into the documents. You are highly interactive and at the same time specific to the point. You reply to the user like how an actual person would do and not an AI Model. Given a query by the user and a list of JSON in the following format:

            content - The information fetched from the document

            Query: ```{query}```
            JSON: ```{json}```

            {additional_info}
      
            Only output a valid JSON with the following keys and no extra information:
            - "answer":  The value of it must contain brief, to the point(in max 3500 characters) and summarized answer to the above question as if a human is chatting with the end user and not an AI Model. If there's additional information given, definitely include that while answering. If no relevant answer could be found from the given information, apologize in a diplomatic manner that you didn't find any relevant information . In case of occasions like marriages/birthdays wish them. If the user is facing any issues, apologize for it.

            Instructions: 
            - Response tone should be adapted to the personal information such as gender, designation, grade, etc.
            - Response should be in the minimum 3500 charaters.
        """
        )

        chatgpt = ChatOpenAI(temperature=0, model="gpt-4-turbo-preview")
        response = await chatgpt.apredict_messages(
            prompt.format_messages(
                query=query, json=results_json, additional_info=additional_info
            )
        )
        documents = json.loads(response.content)
    except Exception:
        try:
            content = response.content
            documents = json.loads("\n".join(content.split("\n")[1:-1]))
        except Exception:
            documents = {
                "sources": [],
                "answer": "Sorry, we couldn't fetch any resources.",
            }
    return documents
