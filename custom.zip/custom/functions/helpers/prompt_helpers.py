import logging
import os
import re
import json
from openai import AsyncAzureOpenAI
from aistudiobot.aistudio.utils.common import CommonUtils
from datetime import datetime

LOG_FILE = r"E:\\aistudio-packages\\Chatbot-Webservice\\cognibot\\logs\\trigger_log.txt"
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
 
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Fetch username from credentials
credential = CommonUtils.get_credential("Azure")
version = credential.value1  
url = credential.value2 
key = credential.value3 
model = credential.value4

# Initialize Azure OpenAI client
client = AsyncAzureOpenAI(
        api_version=version,
        azure_endpoint=url,
        api_key=key,
    )

async def guess_month(utterance):
    
    currentdate = datetime.now()
    formatted_date = currentdate.strftime("%b %Y").upper()
    current_year=str(currentdate.year)
    entity_prompt = """
    Task: Extract "month" and "year" from the user query: {user_input}.
    Context: - Current Date: {formatted_date} (e.g., JAN 2026)
    Rules:
    Format: Return the month as an uppercase 3-letter abbreviation (e.g., JAN, FEB).
    Missing Year Logic: If the user provides a month but no year, use {CURRENT_YEAR}.
    No Future Dates: If using the current year would result in a future month (relative to today), use the previous year instead. (e.g., If today is JAN 2026 and user says "Dec payslip", return DEC 2025).
    Missing Data: If no month is found, return "month": "NA". If no year is found and no month is provided, return "year": "NA".
    JSON Only: Return only a valid JSON object. No prose, no markdown blocks, no extra characters.
    Expected JSON Format:{{"month": "JAN", "year": "2025"}}
    
   """
    #"""
    #Extract the month from the user query {user_input}. 

    #- If a month is provided, return it in uppercase 3-letter abbreviation format (e.g., JAN, FEB, MAR).
    #- If no month is provided, return "month": "NA".
    #- If Year is provided return it "year": "value"

    #Return only the following JSON format without any explanation or extra characters:
    #{{"month": "APR", "year": "2025"}}

    #Do not include any extra text, just return the JSON.    
    #"""
   
    formatted_prompt = entity_prompt.format(
        user_input=utterance,
        formatted_date=formatted_date,
        CURRENT_YEAR=current_year
    )
    
    logger.info(f"current month:{formatted_date}")
    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    print("response guess month%s",response)
    return response.choices[0].message.content

async def pick_month_year(utterance):
    entity_prompt = """
        Extract the month and year from the user query  ```{user_input}```. 

        - If a month is provided, return it in uppercase 3-letter abbreviation format (e.g., JAN, FEB, MAR).
        - If a year is provided in 2-digit format (e.g., 25), convert it to a 4-digit format (e.g., 2025).
        - If no month is provided, return "month": "NA". do not add as a None.
        - If no year is provided, return "year": "NA". do not add as a None.

        Return only the following JSON format without any explanation or extra characters:
        {{"month": "APR", "year": "2025"}}

        Do not include any extra text, just return the JSON.    
    """
   
    formatted_prompt = entity_prompt.format(
        user_input=utterance
    )
    #logger.info("Prompt to pick_month_year: %s",formatted_prompt)

    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    #logger.info("response Year Month: %s",response)
    return response.choices[0].message.content

async def summarize_issue(utterance,personal_details,restricted_details):
    print("in summarize query============================================")
    problem_prompt = """
    Given a user query:
    Query: ```{query}```
 
    First, identify the exact personal detail the user is requesting.
    Do not answer anything else. Do not guess additional details.
 
    To answer the user query, first use the below restricted personal details JSON as the ONLY source:
    ```{restricted_details}
 
    If AND ONLY IF the requested detail is NOT present in restricted personal details,
    then answer using the below full personal details JSON:
    ```{personal_details}
 
    If the user asks for "my personal details", "my details", my info, "employee details", "profile details", 
    or anything similar meaning all details,
    you MUST display ALL available restricted personal details.
 
    Your task is to respond in a conversational, natural way, like a human person would. You should:
    - Understand what the query is asking for and respond ONLY with that detail.
    - Keep the response concise.
    - If the user asks for "all personal details" or "personal information" or overall details, 
      then only show all available details.
    - Recognize equivalent wording, e.g. "date of joining" = hire date.
    - Keep address in one line and short.
    - Provide clear, concise information in a friendly tone.
    - If the information is not available in either source, acknowledge that politely.
    - Avoid mentioning you are an AI or system.
 
    Steps:
    - Step 1: Identify the exact requested field (e.g. manager ID, phone, region, DOB, etc.).
    - Step 2: Search ONLY that field in restricted personal details.
    - Step 3: If the field does not exist there, search ONLY that same field in full personal details.
    - Step 4: If still not found → say:
      "Unfortunately, I don’t have that information right now."
      PRIORITY STRICT RULES:
    - Do NOT ask clarifying questions when the user requests their personal details. Always respond directly.
    - DO NOT answer with any other field if the requested one is unavailable.
    - DO NOT replace, guess, or assume another personal detail.
    - Output only the relevant response.
    - Strictly always display details point-wise in the format:
      Title: Value
 
    THIS INSTRUCTION OVERRIDES ALL OTHER TONE OR CONVERSATION RULES:
    If the user asks for their personal details (single or all),
    DO NOT ask clarifying questions — ALWAYS respond with the available details as per the rules above.
    """
    formatted_prompt = problem_prompt.format(
        query=utterance,
        restricted_details= restricted_details,
        personal_details=personal_details
    )

    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    logger.info("This is Personal detail response===============> %s",response)
    return response.choices[0].message.content


async def guess_financial_year(utterance):
    entity_prompt = """
            Extract the financial year from the user query.

            query: ```{user_input}```

            Rules:

            1. Detect any year in the query in one of the following formats:
            - YY-YY (e.g., 24-25)
            - YYYY-YYYY (e.g., 2024-2025)
            - single YY (e.g., 25)

            2. If the format is YY-YY:
            - Convert it to YYYY-YYYY (e.g., 24-25 → 2024-2025).

            3. If the format is YYYY-YYYY:
            - Return it as is.

            4. If the format is single YY:
            - Convert YY to a full year using "20" prefix → full_year (e.g., 25 → 2025).
            - Then subtract 1 to get the previous year → prev_year = full_year - 1.
            - financial_year = prev_year + "-" + full_year  
              (e.g., 25 → 2024-2025).

            5. If no year is found, return an empty dictionary.

            6. Output must be EXACT JSON only:
            {{ "year": "<value>" }}      
        """
   
    formatted_prompt = entity_prompt.format(
        user_input=utterance,
    )

    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    return response.choices[0].message.content

async def Prefilled_ApplyLeave(utterance):
    
   
    problem_prompt = """
    Data Extraction Prompt
System Role: You are a Data Extraction Specialist. Your task is to parse user leave requests and return a structured JSON object.
Input Query: {user_query}
Current Date (IST): {current_date}
Extraction Rules:
Identify Leave Type: Match against: Bereavement Leave, Casual/Sick Leave, Compensatory off_leave, Earned Leave, Mandatory Leave, Marriage Leave, Paternity Leave, Maternity_Leave. If no match, set to empty string.
Calculate IST Dates (yyyy-MM-dd):
- Reference: Use the Current Date (IST) to determine the year.

- Future Logic: Leave dates must always be in the future. If the requested day/month has already passed in the current year, assume the date refers to the next calendar year.

- Working Days: If a duration is specified (e.g., "4 days"), calculate the endDate by excluding Saturdays and Sundays.
Format: All dates (startDate, endDate, compoffdate) must be returned strictly in yyyy-MM-dd format.
Extract Metadata:
- Reason: Map the "why" to the comment field.

- Specifics: Identify bereavement details (relation/name) for relation give ouput as 1 for value Husband like wise 2 for Wife, 3 for Father, 4 for Mother, 5 for Father in Law, 6 for Mother in Law, 7 for Son, 8 for Daughter, 9 for Brother, 10 for Sister, paternity (child's DOB), or maternity (number of children).
STRICT INSTRUCTION: Provide ONLY the JSON object. No preamble or explanations.
 
Output JSON Schema:
{{ "leaveType": "string or ''", "startDate": "yyyy-MM-dd or ''", "endDate": "yyyy-MM-dd or ''", "comment": "string or ''", "bereavementRelation": "string or ''", "bereavementName": "string or ''", "paternityChildDOB": "string or ''", "maternityNumberOfChild": "number or ''", "compoffdate": "yyyy-MM-dd or ''" }}
    """
    formatted_prompt = problem_prompt.format(
        user_query=utterance,
        current_date=datetime.now()
    )
    logger.info("Prefilled apply leave: %s",formatted_prompt)

    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    JS1=response.choices[0].message.content
    logger.info(f"Response prompt : {JS1}")
    
    # Remove the markers
    clean_str = JS1.replace("```json", "").replace("```", "").strip()

    # Convert to valid JSON (Python dict)
    result = json.loads(clean_str)

    #text=JS1
    #pattern = re.compile(r'''(?s)
    #^(?=.*?"leaveType"\s*:\s*"(?P<leaveType>[^"]*)"|null)
    #(?=.*?"startDate"\s*:\s*"(?P<startDate>[^"]*)"|null)
    #(?=.*?"endDate"\s*:\s*"(?P<endDate>[^"]*)"|null)
    #(?=.*?"comment"\s*:\s*"(?P<comment>[^"]*)"|null)
    #(?=.*?"bereavementRelation"\s*:\s*(?:"(?P<bereavementRelation>[^"]*)"|null))
    #(?=.*?"bereavementName"\s*:\s*(?:"(?P<bereavementName>[^"]*)"|null))
    #(?=.*?"paternityChildDOB"\s*:\s*(?:"(?P<paternityChildDOB>[^"]*)"|null))
    #(?=.*?"maternityNumberOfChild"\s*:\s*(?:"(?P<maternityNumberOfChild>[^"]*)"|null))
    #(?=.*?"compoffdate"\s*:\s*(?:"(?P<compoffdate>[^"]*)"|null))
    #.*$''', re.VERBOSE)

    #m = pattern.search(text)
    #logger.info(f"M: {m}")
    # Convert named groups; normalize nulls to None
    #result = {k: (v if v is not "null" else "") for k, v in (m.groupdict() if m else {}).items()}
    
    logger.info(f"Json body for Leave :{result}")
    logger.info(f"Prefiller apply leave Response: {response}")
    return result

async def Prefilled_Attendance(utterance):

    attendance_prompt = """
Data Extraction Prompt
System Role: You are a Data Extraction Specialist. Your task is to parse user attendence requests and return a single structured JSON.
Input Query: {attend_prompt}
Current Date (IST): {today_date}
Extraction Rules:
Identify attendance Type: Match against: On Duty On Tour -RL, Forgot/Unable to Login, Mark_for_today_ODT, WFO, WFH. If no match, set to null and if match found then return mention attendance type(Note: Keyword → Attendance Type Mapping

On Duty (Regularization) OR On Tour (Regularization) → On Duty On Tour -RL OR forgot to login OR forgot login OR unable to login OR unable to log in → Forgot/Unable to Login OR Mark today on duty OR Mark today on tour → Mark_for_today_ODT OR Mark For Today - Work From Office OR work from office OR WFO → WFO OR Mark For Today - Work From Home OR work from home OR WFH → WFH).
Calculate IST Dates (yyyy-MM-dd):
- Reference: Use the Current Date (IST) to determine the year.

- Future Logic: attendence dates must always be in the past. If the requested day/month has already passed in the current year, assume the date refers to the next calendar year and if user mention yesterday then take start date and end date as same.

- Working Days: If a duration is specified (e.g., "4 days"), calculate the endDate by excluding Saturdays and Sundays.
Format: All dates (startDate, endDate) must be returned strictly in yyyy-MM-dd format.

STRICT INSTRUCTION: Provide ONLY the JSON object. No preamble or explanations.
 
Output JSON Schema:
{{ "attendType": "string or null", "startDate": "yyyy-MM-dd or null", "endDate": "yyyy-MM-dd or null" }}
"""
    formatted_prompt = attendance_prompt.format(
        attend_prompt=utterance,
        today_date=datetime.now()
    )
    logger.info("Prefilled attendance: %s",formatted_prompt)

    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    
    JS1=response.choices[0].message.content
    #text=JS1
    #pattern = re.compile(r'''(?s)
    #^(?=.*?"attendType"\s*:\s*"(?P<attendType>[^"]*)")
    #(?=.*?"startDate"\s*:\s*"(?P<startDate>[^"]*)")
    #(?=.*?"endDate"\s*:\s*"(?P<endDate>[^"]*)")
    #.*$''', re.VERBOSE)

    #m = pattern.search(text)

    # Convert named groups; normalize nulls to None
    #attend_result = {k: (v if v is not "null" else "null") for k, v in (m.groupdict() if m else {}).items()}
    clean_str = JS1.replace("```json", "").replace("```", "").strip()

    # Convert to valid JSON (Python dict)
    attend_result = json.loads(clean_str)
    logger.info(f"attendence_Result: {attend_result}")
    logger.info(f"attendence Response: {response}")
    return attend_result