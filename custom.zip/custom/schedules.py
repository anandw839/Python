 
import os
import asyncio
import json
import logging
from django.conf import settings
from django.utils import timezone
from datetime import timedelta
from django.db.models import Max
from aistudiobot.models import ChatSession, ChatConversation
from botbuilder.core import TurnContext
from aistudiobot.aistudio.dialog.state import AIStudioConvState, AIStudioUserState
from whatsapp_channel.helpers.whatsapp_helper import WhatsAppHelper
from django.conf import settings as config
from common.utils import generate_random_id
from datetime import datetime
from whatsapp_channel.views import send_message_to_webservice

logger = logging.getLogger(__name__)

class FeedbackSchedule:
    @staticmethod
    def feedback_reminder():
        """
        Fetch sessions from past 2 hours that ended >5 mins ago.
        Skip if last intent is 'feedback', else send WhatsApp feedback message.
        """
        try:
            # def fetch_sessions_needing_feedback():
            #     from django.forms.models import model_to_dict
            #     now = timezone.now()
            #     two_hours_ago = now - timedelta(hours=2)
            #     five_minutes_ago = now - timedelta(minutes=5)
            #     # Step 1: Find the most recent conversation ID per unique user_id
            #     latest_conversation_ids = (
            #         ChatConversation.objects.filter(
            #             start_time__gte=two_hours_ago,
            #             end_time__isnull=False,
            #             end_time__lt=five_minutes_ago,
            #         )
            #         .values("chat_session__user_id")  # Group by user_id value
            #         .annotate(
            #             latest_conv_id=Max("id")
            #         )  # Get latest conversation per user
            #         .values_list("latest_conv_id", flat=True)
            #     )
            #     # Step 2: Fetch the actual conversation objects
            #     conversations = ChatConversation.objects.filter(
            #         id__in=list(latest_conversation_ids)
            #     ).select_related(
            #         "chat_session"
            #     )  # Prevent N+1 queries
            #     if not conversations.exists():
            #         logger.info("No conversations needing feedback")
            #         return []
            #     results = []
            #     for conversation in conversations:
            #         session = conversation.chat_session
            #         if not session:
            #             continue
            #         # Skip if last intent was 'feedback' (already sent)
            #         last_intent = (conversation.intent or "").strip().lower()
            #         if last_intent == "feedback":
            #             logger.debug(
            #                 f"Skipping conversation_id: {conversation.id} "
            #                 f"(user: {session.user_id}) - already has feedback intent"
            #             )
            #             continue
            #         # Mark for feedback
            #         logger.info(
            #             f"Queued feedback for conversation_id: {conversation.id} "
            #             f"(session_id: {session.id}, user: {session.user_id})"
            #         )
            #         results.append(
            #             {
            #                 "session": model_to_dict(session),
            #                 "conversation": model_to_dict(conversation),
            #             }
            #         )
            #     logger.info(f"Found {len(results)} unique users needing feedback")
            #     return results
            def fetch_sessions_needing_feedback():
                from django.forms.models import model_to_dict
                from django.db.models import Max, Subquery, OuterRef, Q
                now = timezone.now()
                two_hours_ago = now - timedelta(hours=2)
                five_minutes_ago = now - timedelta(minutes=5)
                # ---- STEP A: true latest conversation for each user (no time limit) ----
                latest_for_user = ChatConversation.objects.filter(
                    chat_session__user_id=OuterRef("chat_session__user_id")
                ).order_by("-end_time")
                # ---- STEP B: latest conversation per user in last 2 hours ----
                latest_conversation_ids = (
                    ChatConversation.objects.filter(
                        start_time__gte=two_hours_ago,
                    )
                    .values("chat_session__user_id")
                    .annotate(latest_conv_id=Max("id"))
                    .values_list("latest_conv_id", flat=True)
                )
                # ---- STEP C: fetch those conversations & apply inactivity + feedback rules ----
                conversations = (
                    ChatConversation.objects.filter(
                        id__in=list(latest_conversation_ids),
                        end_time__isnull=False,
                        end_time__lt=five_minutes_ago,  # inactive ≥ 5 min
                    )
                    .annotate(
                        latest_intent=Subquery(latest_for_user.values("intent")[:1])
                    )
                    .filter(
                        ~Q(latest_intent__iexact="provide_feedback") &
                        ~Q(latest_intent__iexact="feedback_1") &
                        ~Q(latest_intent__iexact="feedback_2")
                    )  # exclude users who already gave feedback
                    .select_related("chat_session__bot_channel_mapping__bot")
                )
                if not conversations.exists():
                    logger.info("No conversations needing feedback")
                    return []
                results = []
                for conversation in conversations:
                    session = conversation.chat_session
                    if not session:
                        continue
                    # Extract bot_id from the related Bot model
                    bot_id = session.bot_channel_mapping.bot.bot_id
                    logger.info(
                        f"Queued feedback for conversation_id: {conversation.id} "
                        f"(session_id: {session.id}, user: {session.user_id})"
                    )
                    results.append(
                        {
                            "session": model_to_dict(session),
                            "conversation": model_to_dict(conversation),
                            "bot_id": bot_id,
                        }
                    )
                logger.info(f"Found {len(results)} unique users needing feedback")
                return results
            results = fetch_sessions_needing_feedback()
            logger.info(f"Sessions needing feedback: {len(results)}")
            # Collect all activity JSONs first
            activity_jsons = []
            for result in results:
                session = result["session"]
                conversation = result["conversation"]
                bot_id = result["bot_id"]
                
                activity_json = FeedbackSchedule.create_activity_json(
                    session, conversation, bot_id
                )
                activity_jsons.append(activity_json)
            # Send all messages concurrently if there are any
            if activity_jsons:
                async def send_all_messages():
                    """Send all feedback messages concurrently using asyncio.gather"""
                    tasks = [
                        send_message_to_webservice(activity_json)
                        for activity_json in activity_jsons
                    ]
                    return await asyncio.gather(*tasks, return_exceptions=True)
                # Run the async function from sync context
                logger.info(
                    f"Sending {len(activity_jsons)} feedback messages concurrently"
                )
                send_results = asyncio.run(send_all_messages())
                # Log results
                success_count = 0
                error_count = 0
                for idx, result in enumerate(send_results):
                    if isinstance(result, Exception):
                        error_count += 1
                        logger.error(
                            f"Error sending feedback message {idx} "
                            f"(conversation_id: {results[idx]['conversation']['id']}): "
                            f"{repr(result)}"
                        )
                    else:
                        success_count += 1
                        logger.debug(
                            f"Successfully sent feedback for conversation_id: "
                            f"{results[idx]['conversation']['id']}"
                        )
                logger.info(
                    f"Feedback sending complete: {success_count} success, "
                    f"{error_count} errors"
                )
            return activity_jsons
        except Exception as e:
            logger.error(f"Error in feedback_reminder: {repr(e)}", exc_info=True)
            return []
    def create_activity_json(session, conversation, bot_id):
        """Creates a BotBuilder Activity JSON using session and conversation data.
        Args:
            session (dict): Session data from feedback_reminder results.
            conversation (dict): Conversation data from feedback_reminder results.
            bot_id (str): Bot ID from the Bot table.
        Returns:
            dict: BotBuilder Activity JSON.
        """
        return {
            "channelData": {
                "clientActivityID": generate_random_id(),
                "clientTimestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[
                    :-3
                ]
                + "Z",
            },
            "textFormat": "plain",
            "type": "message",
            "channelId": "whatsapp",
            "from": {
                "id": session["user_id"],
                "name": session["username"],
                "role": "user",
            },
            "recipient": {
                "id": bot_id,
                "name": "Bot",
                "role": "bot",
            },
            "conversation": {
                "id": session["bot_framework_conversation_id"],
            },
            "id": generate_random_id(),
            "locale": "en-US",
            "timestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
            "localTimestamp": datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
            + "Z",
            "serviceUrl": config.WA_SERVICE_URL,
            "entities": [
                {
                    "requiresBotState": True,
                    "supportsListening": True,
                    "supportsTts": True,
                    "type": "ClientCapabilities",
                }
            ],
            "text": "provide_feedback",
        }
 
 