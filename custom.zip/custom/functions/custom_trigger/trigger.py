import logging
import os

from aistudio_cognition.cognibot.models import DialogDesigner, Skill
from botbuilder.core import TurnContext
from openai import AsyncAzureOpenAI
from aistudiobot.aistudio.utils.common import CommonUtils
from aistudiobot.aistudio.dialog.state import AIStudioConvState, AIStudioUserState
from aistudiobot.aistudio.utils.constants import Constants



logger = logging.getLogger(__name__)


async def gpt_trigger(
    context: TurnContext,
    aistudio_conv_state: AIStudioConvState,
    aistudio_user_state: AIStudioUserState,
    skill_settings: Skill,
    dialog_designer: DialogDesigner,
):

    # First time it will always trigger Greeting dialog and set visited to True.
    # visited = aistudio_conv_state.get_conv_input_as_param("visited") or False
    # if not visited:
    #     aistudio_conv_state.add_conv_input_as_param("visited", True)
    #     return "Welcome_dialog"

    credential = CommonUtils.get_credential("Azure")
    version = credential.value1  # Fetch username from credentials
    url = credential.value2 
    key = credential.value3 
    model = credential.value4

    conv_params = aistudio_conv_state.get_conv_params()
    descriptions = [
        f"{dialog_designer[dialog].name} : {dialog_designer[dialog].description}"
        for dialog in dialog_designer
        if dialog_designer[dialog].description
    ]

    # Initialize Azure OpenAI client
    client = AsyncAzureOpenAI(
        api_version=version,
        azure_endpoint=url,
        api_key=key,
    )

    logger.info("Dialog and description are: %s",descriptions)

    dialog_selection_prompt = """
           SYSTEM ROLE:
           You are a strict dialog intent classifier for a WhatsApp chatbot.
 
            OUTPUT RULE (MANDATORY):
            - Output MUST be exactly one of the following:
            1) A dialog name from the list
            2) null
            - No sentences
            - No explanations
            - No extra text
            3) **if user query is any greating message in any language (eg. hi,hello) then strictly return welcome_dialog as a dialog name
            
            TASK:
            Determine whether the user intent matches an ACTION dialog.
            
            User Query:
            ```{prompt}```
            
            Available Dialogs:
            ```{dialogs}```
            
            RULES:
            - Correct spelling internally before matching
            - If you think its asking for employee related personal information or personal details it should output personalinfo2..
            - Consider different type of related word in personal information or details like phone number or contact details, working region. Similar details also it should output personalinfo.
            - When user wants to apply leave do check if he have given range how much leave he wants output it as prefilled_leave_form.
            - If the intent is INFORMATION-seEKING → output null
            - If the intent is ACTION-oriented:
                - Exact dialog match → output dialog name
                - No match → output null
        """
    

    if context.activity.value:
        notification_prompt = context.activity.value["notification_prompt"]
        if notification_prompt:
            if "leave_type" in context.activity.value:
                leave_type = context.activity.value["leave_type"]
                if notification_prompt.startswith(
                    f"Approve {leave_type} leave of"
                ) or notification_prompt.startswith(f"Reject {leave_type} leave of"):
                    return "approve_reject_leave"
            if notification_prompt.startswith(
                "Initiate the installation request of"
            ) or notification_prompt.startswith("Deny the installation request of"):
                return "initiate_deny_firefox"
            if notification_prompt.startswith(
                "Start installation request"
            ) or notification_prompt.startswith("Reject installation request"):
                return "initiate_deny_pdfeditor"

    utterance = (
        context.activity.value["notification_prompt"]
        if conv_params[Constants.UTTERANCE] == ""

        else conv_params[Constants.UTTERANCE]
    )

    # Format the prompt with actual values
    formatted_prompt = dialog_selection_prompt.format(
        prompt=utterance,
        dialogs="".join(
            [
                f"{i+1}. {description}\n"
                for i, description in enumerate(descriptions)
            ]
        ),
    )

    # Call Azure OpenAI
    response = await client.chat.completions.create(
        model=model,
        messages=[
            {"role": "user", "content": formatted_prompt}
        ],
        temperature=0,
    )
    logger.info("Response===========>",response)
    dialog_name = response.choices[0].message.content
    logging.info(dialog_name)
    if dialog_name != "null":
        return dialog_name
    return "KM"
 