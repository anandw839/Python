import logging

from django.apps import AppConfig
from aistudiobot.aistudio.utils.constants import Constants

logger = logging.getLogger(__name__)


class CustomAppConfig(AppConfig):
    # DO NOT CHANGE OR REMOVE THE BELOW LINE. This would result in custom code not being registered.
    name = Constants.CUSTOM
