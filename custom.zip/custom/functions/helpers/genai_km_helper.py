import base64
import json
import logging
import re
import time
from copy import deepcopy

import aiohttp
from aistudio_cognition.km.genai.genai import AIStudioKMGenAI
from botbuilder.core import MessageFactory, TurnContext
from django.apps import apps

from aistudiobot.aistudio.dialog.state import (
    AIStudioConvState,
    AIStudioUserState,
)
from aistudiobot.aistudio.utils.common import CommonUtils
from aistudiobot.aistudio.utils.constants import Constants
from aistudiobot.helpers.bot_helper import BotHelper
from common.utils import generate_random_id, send_debug_info

logger = logging.getLogger(__name__)

BUFFER_SIZE = 50
DATA_POINTS_REGEX = r"<!-ae=/json/=ae-!>([\s\S]*?)</!-ae=/json/=ae-!>"
TOKENS_START_REGEX = r"<!-ae=/token/=ae-!>([\s\S]*?)$"
TOKENS_END_REGEX = r"</!-ae=/token/=ae-!>"
SOURCES_REGEX = r"\[S(\d+)\]"
MARKDOWN_REGEX = r"\[(?P<text>([^\]]+))\]\((?P<url>https?:\/\/[^\s)]+)\)"
KM_BASE_URL = "https://aime.bajajgeneral.com/km/api"
GENAI_SVG = """<div class='km-title'>
<svg width="20" height="20" viewBox="0 0 349 314" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_100_181)">
<path
d="M281 0L286.351 41.6553C287.759 52.6137 296.386 61.2407 307.345 62.6485L349 68L307.345 73.3514C296.386 74.7593 287.759 83.3863 286.351 94.3447L281 136L275.649 94.3447C274.241 83.3863 265.614 74.7593 254.655 73.3514L213 68L254.655 62.6486C265.614 61.2407 274.241 52.6137 275.649 41.6553L281 0Z"
fill="#739CE1" />
<path
d="M154 6L166.119 100.337C169.308 125.155 188.845 144.692 213.663 147.881L308 160L213.663 172.119C188.845 175.308 169.308 194.845 166.119 219.663L154 314L141.881 219.663C138.692 194.845 119.155 175.308 94.3371 172.119L0 160L94.3371 147.881C119.155 144.692 138.692 125.155 141.881 100.337L154 6Z"
fill="#739CE1" />
<path
d="M66 207L69.0692 230.891C69.8766 237.175 74.8245 242.123 81.1094 242.931L105 246L81.1094 249.069C74.8245 249.877 69.8766 254.825 69.0692 261.109L66 285L62.9308 261.109C62.1234 254.825 57.1755 249.877 50.8906 249.069L27 246L50.8906 242.931C57.1755 242.123 62.1234 237.175 62.9308 230.891L66 207Z"
fill="#739CE1" />
</g>
<defs>
<clipPath id="clip0_100_181">
<rect width="349" height="314" fill="white" />
</clipPath>
</defs>
</svg>
</div>"""


class GenAIKMHelper:
    @staticmethod
    async def authenticate(bot_app, skill_name: str, km_genai: AIStudioKMGenAI):
        CACHE_KEY = Constants.GENAI_CACHE_TOKEN_KEY_BASE + skill_name
        storage_dict = await bot_app.storage.read([CACHE_KEY])
        if CACHE_KEY in storage_dict and storage_dict[CACHE_KEY]:
            cached_token = storage_dict[CACHE_KEY]
            payload = json.loads(
                base64.b64decode(cached_token.split(".")[1] + "==").decode("utf-8")
            )
            # Checking if the JWT token is valid
            if (
                time.time() < payload["exp"] - 300
                and payload["project_id"] == km_genai.km_genai.km_project_id
            ):
                return cached_token

        auth_result = km_genai.authenticate()
        token = None
        if auth_result["success"]:
            token = auth_result["data"]
            await bot_app.storage.write({CACHE_KEY: token})
        return token
    @staticmethod
    def get_citations(km_response: dict):
        """Removes [S1], [S2], etc. from the answer and returns cleaned text + data points."""
        clean_answer = re.sub(r"\[S\d+\]", "", km_response["answer"]).strip()
        citations = km_response.get("data_points", [])
        return clean_answer, citations

    @staticmethod
    def create_km_whatsapp_citation(citations: list):
        """Creates a WhatsApp-friendly citation block."""
        if not citations:
            return ""

        citation_text = "📎 *Citations:*\n\n"
        seen_files = set()

        for i, item in enumerate(citations, start=1):
            file_id = item["url"]
            file_name = item["filename"]
            page_name = item.get("sourcepage", "Document")
            seen_files.add(file_name)

            file_page_url = f"{KM_BASE_URL}/file-page/{file_id}"
            citation_text += f"[{i}] {page_name} → {file_page_url}\n"

        citation_text += "\n📂 *Documents:*\n\n"
        for file_name in seen_files:
            # Find first matching item to get its ID
            file_id = next((c["url"] for c in citations if c["filename"] == file_name), None)
            if file_id:
                doc_url = f"{KM_BASE_URL}/document/{file_id}"
                citation_text += f"{file_name} → {doc_url}\n"

        return citation_text.strip()



    @staticmethod
    async def query(
        context: TurnContext,
        aistudio_conv_state: AIStudioConvState,
        aistudio_user_state: AIStudioUserState,
        user_query: str,
        to_stream: bool = False,
        history: list = [],
        filters: list = [],
        show_other_references=False,
        dont_know_pattern=r"<IDONTKNOW\s*/>",
    ):
        km_response = {"answer": ""}

        bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
        cognibot = bot_app.cognibot

        # Get the GenAI settings for current skill
        conv_params = aistudio_conv_state.get_conv_params()
        user_params = aistudio_user_state.get_user_params()
        skill = conv_params.get(Constants.SKILL)
        skill_settings = cognibot.skill_settings_map.get(skill)
        if not skill_settings.km_enabled:
            return "KM Setting for skill not enabled"
        km_genai = BotHelper.get_km_details(skill_settings, cognibot.km_settings_list)

        cipher = CommonUtils.get_cipher()
        km_genai_copy = deepcopy(km_genai)
        km_genai_copy.km_genai.km_project_secret = cipher.decrypt(
            km_genai.km_genai.km_project_secret
        )
        km_url = km_genai_copy.km_genai.url + "/api"

        debug = user_params.get(Constants.DEBUG_TRACE)

        # Authenticate with KM Service
        token = await GenAIKMHelper.authenticate(bot_app, skill, km_genai_copy)
        if not token:
            return "Error while authenticating with KM Service"

        # Query KM Service
        # output = ""
        # activity_id = None
        # if to_stream:
        #     buffer = ""
        #     try:
        #         async for data in km_genai_copy.genai_query_streaming(
        #             token, user_query, history, filters, debug
        #         ):
        #             if data.strip() != "null":
        #                 buffer += data

        #                 while len(buffer) >= BUFFER_SIZE:
        #                     # Append the first buffer size chararacters to the overall output
        #                     output += buffer[:BUFFER_SIZE]
        #                     # Remove these characters from buffer
        #                     buffer = buffer[BUFFER_SIZE:]
        #                     km_response = await GenAIKMHelper._process_stream(
        #                         context, output, km_response, debug
        #                     )
        #                     activity_id = await GenAIKMHelper._parse_send_response(
        #                         km_url,
        #                         km_response,
        #                         context,
        #                         activity_id,
        #                         show_other_references,
        #                         dont_know_pattern,
        #                     )
        #         # For pending characters in buffer after we receive the entire response
        #         if buffer:
        #             output += buffer
        #             km_response = await GenAIKMHelper._process_stream(
        #                 context, output, km_response, debug
        #             )
        #             activity_id = await GenAIKMHelper._parse_send_response(
        #                 km_url,
        #                 km_response,
        #                 context,
        #                 activity_id,
        #                 show_other_references,
        #                 dont_know_pattern,
        #             )

        #         output += buffer
        #     except Exception as e:
        #         logger.exception(f"Error while KM service query response parsing, {e}")
        #         return
        # else:
        try:
            km_response = km_genai_copy.genai_query(
                token, user_query, history, filters, debug
            )
            if debug:
                await GenAIKMHelper._send_trace_data(context, km_response)
            # activity_id = await GenAIKMHelper._parse_send_response(
            #     km_url,
            #     km_response,
            #     context,
            #     activity_id,
            #     show_other_references,
            #     dont_know_pattern,
            # )

            # activity = MessageFactory.text(km_response["answer"])
            # await context.send_activity(activity)
            print("KM_response for citations=====",km_response)
            answer, citations = GenAIKMHelper.get_citations(km_response)
            citation_text = GenAIKMHelper.create_km_whatsapp_citation(citations)
            #ation_text = create_km_whatsapp_citation(citations)

            #full_message = f"{answer}\n\n{citation_text}"
            full_message = f"{answer}"
            #clean_answer = re.sub(r"\[S\d+\]", "", km_response["answer"])
            # fullmsg = f"{clean_answer}\n\n{citation_text}"

            #activity = MessageFactory.text(clean_answer.strip())
            activity = MessageFactory.text(full_message)
            await context.send_activity(activity)

        except Exception as e:
            logger.exception(f"Error while KM service query response parsing, {e}")
            return

        # print("ouput from the km is", km_response["answer"])

        return km_response

    @staticmethod
    def _create_km_html_output(km_url, answer, citations, reference_files):
        output_text = ""
        output_text += f"<div><p>{answer}</p></div>"
        citation_text = ""
        reference_text = ""

        if citations:
            citation_text += "<br/><b>Citations:</b><br/>"
        for file_name in citations:
            citation_text += "<div>"
            # Handling citations for files
            if citations[file_name][0].get("id"):
                citation_text += f'<a href="{km_url}/document/{citations[file_name][0]["id"]}">{file_name}</a> : '
                for page in citations[file_name]:
                    citation_text += f'<a href="{km_url}/file-page/{page["id"]}">{page["citation"]}</a> '
            else:
                # Handling citations for URLs
                citation_text += f'<a href="{file_name}">{file_name}</a> : '
                for page in citations[file_name]:
                    citation_text += f'<a href="{file_name}">{page["citation"]}</a> '
            citation_text += "</div><br/>"

        if reference_files:
            reference_text += "<br/><b>Other References:</b></br>"
        for file_name, uuid in reference_files.items():
            reference_text += "<div>"
            if uuid:
                reference_text += f'<a href="{km_url}/document/{uuid}">{file_name}</a>'
            else:
                # Handling citations for URLs
                reference_text += f'<a href="{file_name}">{file_name}</a> : '
            reference_text += "</div><br/>"

        output_text += f"<div class='citation'>{citation_text}</div>"
        output_text += f"<div class='citation'>{reference_text}</div>"

        return output_text

    @staticmethod
    def _process_km_response(km_url, response):
        matches = re.findall(SOURCES_REGEX, response["answer"])
        source_nos = [int(match) for match in matches]
        files = {}

        updated_message = response["answer"]
        updated_message = updated_message.replace("```html", "").replace("```", "")
        markdown_matches = re.findall(MARKDOWN_REGEX, updated_message)
        if markdown_matches:
            updated_message = re.sub(
                MARKDOWN_REGEX,
                r"<a href='\g<url>' target='_blank' rel='noopener noreferrer'>\g<text></a>",
                updated_message,
            )

        for i, source_no in enumerate(set(source_nos)):
            data_point = response["data_points"][source_no - 1]
            if data_point:
                filename = data_point.get("filename")
                # Processing file related data points
                if data_point.get("url"):
                    uuid = data_point["url"]
                    files.setdefault(filename, []).append(
                        {"id": uuid, "citation": i + 1}
                    )
                    updated_message = updated_message.replace(
                        f"[S{source_no}]",
                        f'<a href="{km_url}/file-page/{uuid}">{i + 1}</a>',
                    )
                else:
                    # Processing URL related data points
                    files.setdefault(filename, []).append({"citation": i + 1})
                    updated_message = updated_message.replace(
                        f"[S{source_no}]",
                        f'<a href="{filename}">{i+1}</a>',
                    )

        return updated_message, files

    @staticmethod
    async def _parse_send_response(
        km_url: str,
        km_response: dict,
        context: TurnContext,
        activity_id: str,
        show_other_references: bool,
        dont_know_pattern: str,
    ):
        if km_response["answer"]:
            updated_km_response, source_files = GenAIKMHelper._process_km_response(
                km_url, km_response
            )

            reference_files = {}
            # Only if we need to show other references, execute the next code block
            if show_other_references:
                # Check if GenAI has an answer, if not do not show references
                match = re.search(dont_know_pattern, updated_km_response, re.IGNORECASE)
                if not match:
                    # Get all the referenced data points from km_response
                    data_points = {
                        file["filename"]: file.get("url")
                        for file in km_response.get("data_points", [])
                    }
                    cited_filenames = set(source_files.keys())
                    reference_files = {
                        filename: data_points[filename]
                        for filename in data_points
                        if filename not in cited_filenames
                    }

            output_text = GenAIKMHelper._create_km_html_output(
                km_url, updated_km_response, source_files, reference_files
            )
            activity = MessageFactory.text(GENAI_SVG + output_text)
            activity.conversation = context.activity.conversation
            if not activity_id:
                response = await context.send_activity(activity)
                activity_id = response.id
            else:
                activity.id = activity_id
                await context.update_activity(activity)
        return activity_id

    @staticmethod
    async def _process_stream(context, stream_data, km_response, debug):
        if stream_data.strip():
            if not km_response.get("data_points"):
                matches = re.findall(DATA_POINTS_REGEX, stream_data)
                if matches:
                    km_response = json.loads(matches[0])
                    if debug:
                        await GenAIKMHelper._send_trace_data(context, km_response)
                    km_response["answer"] = re.sub(DATA_POINTS_REGEX, "", stream_data)
            else:
                token_matches = re.findall(TOKENS_START_REGEX, stream_data)
                if token_matches:
                    token_end_matches = re.findall(TOKENS_END_REGEX, token_matches[0])
                    if token_end_matches:
                        tokens_data = re.sub(TOKENS_END_REGEX, "", token_matches[0])
                        km_response["tokens"] = json.loads(tokens_data)
                        if debug:
                            await GenAIKMHelper._send_trace_data(context, km_response)
                answer = re.sub(DATA_POINTS_REGEX, "", stream_data)
                km_response["answer"] = re.sub(TOKENS_START_REGEX, "", answer)

        return km_response

    @staticmethod
    async def _send_trace_data(context: TurnContext, debug_info):
        trace_km_call = {
            "id": generate_random_id(),
            "operation": "Datapoints and Thoughts from KM Service",
        }
        await send_debug_info(
            context,
            info={"details": debug_info},
            trace=trace_km_call,
        )

    @staticmethod
    async def get_tags(
        context: TurnContext,
        aistudio_conv_state: AIStudioConvState,
        aistudio_user_state: AIStudioUserState,
    ):
        bot_app = apps.get_app_config(Constants.AISTUDIOBOT)
        cognibot = bot_app.cognibot
        conv_params = aistudio_conv_state.get_conv_params()
        skill = conv_params.get(Constants.SKILL)
        skill_settings = cognibot.skill_settings_map.get(skill)
        if not skill_settings.km_enabled:
            return "KM Setting for skill not enabled"
        cipher = CommonUtils.get_cipher()
        km_genai = BotHelper.get_km_details(skill_settings, cognibot.km_settings_list)
        km_genai_copy = deepcopy(km_genai)
        km_genai_copy.km_genai.km_project_secret = cipher.decrypt(
            km_genai.km_genai.km_project_secret
        )
        # Build the tags URL
        km_tags_url = km_genai_copy.km_genai.url + "/api/tags"
        tags_list = []

        # Authenticate with KM Service
        try:
            token = await GenAIKMHelper.authenticate(bot_app, skill, km_genai_copy)
            if not token:
                logger.error("Error while authenticating with KM Service")
                return tags_list  # Return an empty list if authentication fails
        except Exception as e:
            logger.exception(f"Authentication error: {e}")
            return tags_list

        # Fetch tags from KM Service
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(km_tags_url, headers=headers) as response:
                    if response.status == 200:
                        tags_list = await response.json()
                    else:
                        logger.error(
                            f"Failed to retrieve tags, status code: {response.status}"
                        )
        except Exception as e:
            logger.exception(f"Error while retrieving tags from KM service: {e}")
        return tags_list
