from collections import defaultdict

from botbuilder.schema import ActivityTypes

from aistudiobot.helpers import BotHelper
from custom.functions.helpers.km import DOCUMENT_URL


def create_leave_card(leaves):
    card = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {
                "type": "Container",
                "items": [
                    {
                        "type": "TextBlock",
                        "text": "Here is the list of leaves fetched:",
                        "wrap": True,
                    }
                ],
            }
        ],
    }
    for leave in leaves:
        card["body"][0]["items"].append(
            {
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {
                                "type": "TextBlock",
                                "text": f"{leave.leave_type[0].upper()}{leave.leave_type[1:].lower()}",
                                "wrap": True,
                                "weight": "Bolder",
                                "height": "stretch",
                            }
                        ],
                    },
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {
                                "type": "TextBlock",
                                "text": f"{leave.leaves}",
                                "wrap": True,
                            }
                        ],
                    },
                ],
                "horizontalAlignment": "Left",
                "separator": True,
            }
        )
    return card


def create_km_card(documents):
    km_card = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [{"type": "Container", "items": []}],
    }
    km_card["body"][0]["items"].append(
        {
            "type": "RichTextBlock",
            "inlines": [{"type": "TextRun", "text": documents["answer"]}],
        }
    )
    source_map = defaultdict(set)
    for source in documents["sources"]:
        if source["page"]:
            source_map[source["source"]].add(str(source["page"]))
        else:
            source_map[source["source"]] = []
    for source in source_map:
        title = source
        if len(source_map[source]) > 0:
            title = (
                f"{title} : {(', '.join(sorted(list(source_map[source]), key=int)))}"
            )
        km_card["body"].append(
            {
                "type": "ActionSet",
                "actions": [
                    {
                        "type": "Action.OpenUrl",
                        "title": title,
                        "url": f"{DOCUMENT_URL}/{source}",
                    }
                ],
            }
        )
    return km_card


async def send_leave_push_notification(
    context, session, text, reason, firstname, username, leave_type, manager_firstname
):
    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    card_template = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {
                "type": "TextBlock",
                "text": "Leave Application Received",
                "wrap": True,
                "size": "Large",
                "color": "Accent",
            },
            {"type": "TextBlock", "text": text, "wrap": True},
            {"type": "TextBlock", "text": "Reason :"+reason, "wrap": True},],
            "actions": [
        {
            "type": "Action.Submit",
            "title": "Approve",
            "data": {
                                            "notification_prompt": f"Approve {leave_type} leave of {firstname}",
                                            "leave_type": leave_type,
                                            "username": username,
                                            "approved": True,
                                            "manager_firstname": manager_firstname,
                                        },
        },
        {
            "type": "Action.Submit",
            "title": "Reject",
            "data": {
                                            "notification_prompt": f"Reject {leave_type} leave of {firstname}",
                                            "leave_type": leave_type,
                                            "username": username,
                                            "approved": False,
                                            "manager_firstname": manager_firstname,
                                        },
        }
    ]
    }
    attachment = {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": card_template,
        "contentUrl": None,
    }
    json_data = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [attachment],
        "attachmentLayout": "carousel",
    }
    access_token = ""
    if channel == "msteams":
        access_token = await BotHelper.authenticate_ms_bot()
    service_url = (
        context.activity.service_url
        + "/v3/conversations/"
        + session.bot_framework_conversation_id
        + "/activities/reply"
    )
    response = await BotHelper.call_service_url(access_token, service_url, json_data)


async def send_leave_approval_status(context, session, title, text):
    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    card_template = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {
                "type": "TextBlock",
                "text": title,
                "wrap": True,
                "size": "Large",
                "color": "Accent",
            },
            {"type": "TextBlock", "text": text, "wrap": True},
        ],
    }
    attachment = {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": card_template,
        "contentUrl": None,
    }
    json_data = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [attachment],
        "attachmentLayout": "carousel",
    }
    access_token = ""
    if channel == "msteams":
        access_token = await BotHelper.authenticate_ms_bot()
    service_url = (
        context.activity.service_url
        + "/v3/conversations/"
        + session.bot_framework_conversation_id
        + "/activities/reply"
    )
    response = await BotHelper.call_service_url(access_token, service_url, json_data)


async def send_installation_request(
    context,
    session,
    text,
    firstname,
    lastname,
    username,
    manager_firstname,
    manager_lastname,
):
    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    card_template = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {
                "type": "TextBlock",
                "text": "Installation Request Received",
                "wrap": True,
                "size": "Large",
                "color": "Accent",
            },
            {"type": "TextBlock", "text": text, "wrap": True},
            {
                "type": "ColumnSet",
                "columns": [
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {
                                "type": "ActionSet",
                                "actions": [
                                    {
                                        "type": "Action.Submit",
                                        "title": "Approve",
                                        "data": {
                                            "notification_prompt": f"Initiate the installation request of {firstname} {lastname}",
                                            "username": username,
                                            "approved": True,
                                            "manager_firstname": manager_firstname,
                                            "manager_lastname": manager_lastname,
                                        },
                                    }
                                ],
                            }
                        ],
                    },
                    {
                        "type": "Column",
                        "width": "stretch",
                        "items": [
                            {
                                "type": "ActionSet",
                                "actions": [
                                    {
                                        "type": "Action.Submit",
                                        "title": "Reject",
                                        "data": {
                                            "notification_prompt": f"Deny the installation request of {firstname} {lastname}",
                                            "username": username,
                                            "approved": False,
                                            "manager_firstname": manager_firstname,
                                            "manager_lastname": manager_lastname,
                                        },
                                    }
                                ],
                            }
                        ],
                    },
                ],
            },
        ],
    }
    attachment = {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": card_template,
        "contentUrl": None,
    }
    json_data = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [attachment],
        "attachmentLayout": "carousel",
    }
    access_token = ""
    if channel == "msteams":
        access_token = await BotHelper.authenticate_ms_bot()
    service_url = (
        context.activity.service_url
        + "/v3/conversations/"
        + session.bot_framework_conversation_id
        + "/activities/reply"
    )
    response = await BotHelper.call_service_url(access_token, service_url, json_data)


async def send_installation_request_forpdf(
    context,
    session,
    text,
    firstname,
    lastname,
    username,
    manager_firstname,
    manager_lastname,
):
    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    card_template = {
        "type": "AdaptiveCard",
        "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
        "version": "1.5",
        "body": [
            {
                "type": "TextBlock",
                "text": "Installation Request Received",
                "wrap": True,
                "size": "Large",
                "color": "Accent",
            },
            {"type": "TextBlock", "text": text, "wrap": True},],
            "actions": [
        {
            "type": "Action.Submit",
            "title": "Approve",
            "data": {
                "notification_prompt": f"Start installation request{firstname} {lastname}",
                "username": username,
                "approved": True,
                "manager_firstname": manager_firstname,
                "manager_lastname": manager_lastname,
            }
        },
        {
            "type": "Action.Submit",
            "title": "Reject",
            "data": {
                "notification_prompt": f"Reject installation request{firstname} {lastname}",
                "username": username,
                "approved": False,
                "manager_firstname": manager_firstname,
                "manager_lastname": manager_lastname,
            }
        }
    ]
    }
    attachment = {
        "contentType": "application/vnd.microsoft.card.adaptive",
        "content": card_template,
        "contentUrl": None,
    }
    json_data = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [attachment],
        "attachmentLayout": "carousel",
    }
    access_token = ""
    if channel == "msteams":
        access_token = await BotHelper.authenticate_ms_bot()
    service_url = (
        context.activity.service_url
        + "/v3/conversations/"
        + session.bot_framework_conversation_id
        + "/activities/reply"
    )
    response = await BotHelper.call_service_url(access_token, service_url, json_data)


async def trigger_installation_workflow(context, session):
    from asyncio import create_task

    from botbuilder.schema import Activity
    from django.apps import apps
    from django.conf import settings

    from aistudiobot.aistudio.utils.constants import Constants
    from aistudiobot.helpers.bot_helper import BotHelper
    from common.constants import HTTPConstants
    from common.jwt_utils import JWTUtils

    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    activity_json = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [],
        "value": {"__trigger_aistudio_dialog__": "start_firefox_installation"},
        "serviceUrl": context.activity.service_url,
    }

    is_azure_bot = any(
        [
            context.activity.service_url.startswith(url)
            for url in [
                "https://smba.trafficmanager.net",
                "https://webchat.botframework.com",
            ]
        ]
    )

    bot_app = apps.get_app_config(Constants.AISTUDIOBOT)

    if is_azure_bot:
        adapter = bot_app.adapter_azure
    else:
        adapter = bot_app.adapter

    activity = Activity.deserialize(activity_json)

    jwt = JWTUtils.create_jwt_for_webservice(
        settings.AE_APP_ID, settings.AE_APP_PASSWORD, validity=60 * 60 * 24
    )
    activity.additional_properties["auth_header"] = HTTPConstants.BEARER + jwt

    bot = bot_app.bot

    async def aux_func(turn_context):
        await bot.on_turn(turn_context)

    identity = BotHelper.get_identity(is_azure_bot, context.activity.service_url)

    if identity.claims:
        # when Azure adapter activity is processed from push_notifications call we add claims dict to
        # activity.additional_properties to use when calling process_activity_with_identity elsewhere in code.
        activity.additional_properties["claims"] = identity.claims
    create_task(adapter.process_activity_with_identity(activity, identity, aux_func))
    # bot = bot_app.bot

    # async def aux_func(turn_context):
    #     await bot.on_turn(turn_context)

    # identity = BotHelper.get_identity(False, context.activity.service_url)
    # await adapter.process_activity_with_identity(
    #     json_data, identity, aux_func
    # )
    # access_token = ""
    # if channel == "msteams":
    #     access_token = await BotHelper.authenticate_ms_bot()
    # service_url = "/api/messages"
    # response = await BotHelper.call_service_url(access_token, service_url, json_data)


async def trigger_installation_workflow_forpdfeditor(context, session):
    from asyncio import create_task

    from botbuilder.schema import Activity
    from django.apps import apps
    from django.conf import settings

    from aistudiobot.aistudio.utils.constants import Constants
    from aistudiobot.helpers.bot_helper import BotHelper
    from common.constants import HTTPConstants
    from common.jwt_utils import JWTUtils

    bot_id = context.activity.recipient.id
    bot_name = context.activity.recipient.name
    channel = context.activity.channel_id

    from_details = {
        "id": bot_id,
        "name": bot_name,
        "role": "bot",
    }

    recipient_details = {
        "id": session.user_id,
        "name": session.username,
        "role": "user",
    }

    conversation_details = {
        "id": session.bot_framework_conversation_id,
    }
    activity_json = {
        "type": ActivityTypes.message,
        "name": "Notification",
        "conversation": conversation_details,
        "channelId": channel,
        "from": from_details,
        "recipient": recipient_details,
        "attachments": [],
        "value": {"__trigger_aistudio_dialog__": "start_pdf_installation"},
        "serviceUrl": context.activity.service_url,
    }

    is_azure_bot = any(
        [
            context.activity.service_url.startswith(url)
            for url in [
                "https://smba.trafficmanager.net",
                "https://webchat.botframework.com",
            ]
        ]
    )

    bot_app = apps.get_app_config(Constants.AISTUDIOBOT)

    if is_azure_bot:
        adapter = bot_app.adapter_azure
    else:
        adapter = bot_app.adapter

    activity = Activity.deserialize(activity_json)

    jwt = JWTUtils.create_jwt_for_webservice(
        settings.AE_APP_ID, settings.AE_APP_PASSWORD, validity=60 * 60 * 24
    )
    activity.additional_properties["auth_header"] = HTTPConstants.BEARER + jwt

    bot = bot_app.bot

    async def aux_func(turn_context):
        await bot.on_turn(turn_context)

    identity = BotHelper.get_identity(is_azure_bot, context.activity.service_url)

    if identity.claims:
        # when Azure adapter activity is processed from push_notifications call we add claims dict to
        # activity.additional_properties to use when calling process_activity_with_identity elsewhere in code.
        activity.additional_properties["claims"] = identity.claims
    create_task(adapter.process_activity_with_identity(activity, identity, aux_func))
